<div id="footer">
    <div>
    &laquo;ApPHP EasyInstaller Pro&raquo; <?php echo EI_VERSION;?> &nbsp;<a href="https://www.apphp.com">ApPHP</a>
    <?php if(EI_LICENSE_AGREEMENT_PAGE != ''){ ?>
        : <a href="<?php echo '../'.EI_LICENSE_AGREEMENT_PAGE;?>" target="_blank" rel="noopener noreferrer"><?php echo lang_key('license'); ?></a>
    <?php } ?>
    </div>
</div>
