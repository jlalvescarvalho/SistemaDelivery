<div id="wrapper">
	<header id="header">
		<div class="header-holder">
			<h1 class="logo"><img src="images/logo.png" height="35" width="167" alt="InfoEnem"></h1>
		</div>
	</header>
</div>