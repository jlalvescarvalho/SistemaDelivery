<?php if (!session_id()) session_start();?>
<?php



	session_unset();

 echo "<script>window.location='/'</script>";
 
?>