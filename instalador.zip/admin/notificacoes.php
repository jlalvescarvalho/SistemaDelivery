<?php session_start(); ?>

<?php 

include('../bd.php');

if(@intval($_SESSION['bt_admin_login']) <> '256841') {  echo "<script>window.location='/admin/login.php'</script>"; } ?>  



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Admin</title>

<link href="arquivos/main.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>

    <!-- Emojis no teclado ONESGINAL-->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


</head>



<body onLoad="UR_Start()">

<div class="box_1">

  <div class="box_2"><?php include('top_admin.php'); ?>

  

  <?php include('menu.php'); ?>

   <?php include('lado.php'); ?>        

  

  </div>

  <div class="box_3">

  <div class="box_21">

      <div class="box_12">

        <div class="box_87"> <a href="sair.php">

          <div class="box_88">Sair</div>

        </a></div>

      </div>

      <div class="box_13"></div>

      <div class="box_14"><img src="arquivos/Desktop.png" width="32" height="32" />

          <h5>Enviar notificações para clientes</h5>

      </div>

  <div class="box_15">
    <div class="box_22">




                            <!--Form with header-->
                <form action="send.php" method="post">
                   <div class="row justify-content-center">
        				<div class="col-12 col-md-8 col-lg-6 pb-5">

                                <div class="card border-primary rounded-0">
                                    <div class="card-header p-0">
                                        <div class="bg-info text-white text-center py-2">
                                            <h3><i class="fa fa-envelope"></i> Notificações</h3>
                                            <p class="m-0">Envie Push Notifications para seus clientes.</p>
                                        </div>
                                    </div>
                                    <div class="card-body p-3">
                                      
                                        <center>
                                            <h2>Segmento de Clientes</h2>
                                            <select class="form-group" id="segmentos" name="segmentos">
                                            <option value="Subscribed Users">Todos</option>
                                            <option value="Engaged Users">Clientes Frequentes (Mais de 4 Acessos)</option>
                                            <option value="Inactive Users">Inativos a 1 Semana</option>
                                            <option value="2 semanas">Inativos a 2 Semana</option>
                                            </select>
                                        </center>

                                        <!--Body-->
                                        <div class="form-group">
                                            <div class="input-group mb-2">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="fa fa-envelope text-info"></i></div>
                                                </div>
                                                <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Titulo da Notificação" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="input-group mb-2">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text"><i class="fa fa-comment text-info"></i></div>
                                                </div>
                                                <textarea class="form-control" id="mytext" name="mytext" placeholder="Mensagem da Notificação" data-emojiable="true" required style="margin-top: 0px"></textarea>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <input type="submit" value="Enviar" class="btn btn-info btn-block rounded-0 py-2">
                                        </div>
                                        </div>
                                    </div>

                        </div>
                   	</div>
                </form>


                                    

    </div>
  </div>


        </div>

      </div>

      </div>

  </div>

</div>

</body>

</html>

