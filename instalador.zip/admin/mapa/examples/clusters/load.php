<?php

$macDoList = array(
  array("lat"=>49.00408,"lng"=>2.56228,"data"=>array("drive"=>false,"zip"=>93290,"city"=>"TREMBLAY-EN-FRANCE")),
  array("lat"=>49.00308,"lng"=>2.56219,"data"=>array("drive"=>false,"zip"=>93290,"city"=>"TREMBLAY-EN-FRANCE")),
  array("lat"=>48.93675,"lng"=>2.35237,"data"=>array("drive"=>false,"zip"=>93200,"city"=>"SAINT-DENIS")),
  array("lat"=>48.93168,"lng"=>2.39858,"data"=>array("drive"=>true,"zip"=>93120,"city"=>"LA COURNEUVE")),
  array("lat"=>48.91304,"lng"=>2.38027,"data"=>array("drive"=>true,"zip"=>93300,"city"=>"AUBERVILLIERS")),
  array("lat"=>48.90821,"lng"=>2.51795,"data"=>array("drive"=>false,"zip"=>93190,"city"=>"LIVRY-GARGAN")),
  array("lat"=>48.90672,"lng"=>2.33205,"data"=>array("drive"=>false,"zip"=>93400,"city"=>"SAINT-OUEN")),
  array("lat"=>48.89191,"lng"=>2.44477,"data"=>array("drive"=>true,"zip"=>93130,"city"=>"NOISY-LE-SEC")),
  array("lat"=>48.87986,"lng"=>2.4164,"data"=>array("drive"=>false,"zip"=>93260,"city"=>"LES LILAS")),
  array("lat"=>48.8556,"lng"=>2.41621,"data"=>array("drive"=>false,"zip"=>93100,"city"=>"MONTREUIL")),
  array("lat"=>48.83445,"lng"=>2.56199,"data"=>array("drive"=>true,"zip"=>93160,"city"=>"NOISY-LE-GRAND")),
  array("lat"=>48.83907,"lng"=>2.48585,"data"=>array("drive"=>false,"zip"=>94130,"city"=>"NOGENT-SUR-MARNE")),
  array("lat"=>48.82102,"lng"=>2.41444,"data"=>array("drive"=>false,"zip"=>94220,"city"=>"CHARENTON-LE-PONT")),
  array("lat"=>48.82011,"lng"=>2.47548,"data"=>array("drive"=>true,"zip"=>94340,"city"=>"JOINVILLE-LE-PONT")),
  array("lat"=>48.81429,"lng"=>2.50873,"data"=>array("drive"=>false,"zip"=>94500,"city"=>"CHAMPIGNY-SUR-MARNE")),
  array("lat"=>48.79584,"lng"=>2.41266,"data"=>array("drive"=>true,"zip"=>94400,"city"=>"VITRY-SUR-SEINE")),
  array("lat"=>48.79193,"lng"=>2.36959,"data"=>array("drive"=>true,"zip"=>94800,"city"=>"VILLEJUIF")),
  array("lat"=>48.76182,"lng"=>2.44355,"data"=>array("drive"=>true,"zip"=>94190,"city"=>"VILLENEUVE-SAINT-GEORGES")),
  array("lat"=>48.75845,"lng"=>2.37052,"data"=>array("drive"=>false,"zip"=>94320,"city"=>"THIAIS")),
  array("lat"=>48.75619,"lng"=>2.34647,"data"=>array("drive"=>true,"zip"=>94150,"city"=>"RUNGIS")),
  array("lat"=>48.74476,"lng"=>2.40973,"data"=>array("drive"=>true,"zip"=>94310,"city"=>"ORLY")),
  array("lat"=>48.939,"lng"=>2.52663,"data"=>array("drive"=>true,"zip"=>93270,"city"=>"SEVRAN")),
  array("lat"=>48.93847,"lng"=>2.3565,"data"=>array("drive"=>false,"zip"=>93200,"city"=>"SAINT-DENIS")),
  array("lat"=>48.95829,"lng"=>2.47644,"data"=>array("drive"=>false,"zip"=>93600,"city"=>"AULNAY-SOUS-BOIS")),
  array("lat"=>48.85286,"lng"=>2.48593,"data"=>array("drive"=>false,"zip"=>94120,"city"=>"FONTENAY-SOUS-BOIS")),
  array("lat"=>48.7944,"lng"=>2.55241,"data"=>array("drive"=>true,"zip"=>94490,"city"=>"ORMESSON-SUR-MARNE")),
  array("lat"=>48.8775,"lng"=>2.4751,"data"=>array("drive"=>true,"zip"=>93110,"city"=>"ROSNY-SOUS-BOIS")),
  array("lat"=>48.78475,"lng"=>2.46003,"data"=>array("drive"=>true,"zip"=>94000,"city"=>"CRÉTEIL")),
  array("lat"=>48.82535,"lng"=>2.3942,"data"=>array("drive"=>false,"zip"=>94220,"city"=>"CHARENTON-LE-PONT")),
  array("lat"=>48.77372,"lng"=>2.39927,"data"=>array("drive"=>true,"zip"=>94600,"city"=>"CHOISY-LE-ROI")),
  array("lat"=>48.89732,"lng"=>2.34485,"data"=>array("drive"=>false,"zip"=>75018,"city"=>"PARIS")),
  array("lat"=>48.8986,"lng"=>2.34416,"data"=>array("drive"=>false,"zip"=>75018,"city"=>"PARIS")),
  array("lat"=>48.89588,"lng"=>2.34647,"data"=>array("drive"=>false,"zip"=>75018,"city"=>"PARIS")),
  array("lat"=>48.89052,"lng"=>2.3599,"data"=>array("drive"=>false,"zip"=>75018,"city"=>"PARIS")),
  array("lat"=>48.88865,"lng"=>2.39267,"data"=>array("drive"=>false,"zip"=>75019,"city"=>"PARIS")),
  array("lat"=>48.88755,"lng"=>2.32541,"data"=>array("drive"=>false,"zip"=>75017,"city"=>"PARIS")),
  array("lat"=>48.88555,"lng"=>2.29205,"data"=>array("drive"=>false,"zip"=>75017,"city"=>"PARIS")),
  array("lat"=>48.88388,"lng"=>2.3468,"data"=>array("drive"=>false,"zip"=>75018,"city"=>"PARIS")),
  array("lat"=>48.88235,"lng"=>2.37054,"data"=>array("drive"=>false,"zip"=>75019,"city"=>"PARIS")),
  array("lat"=>48.87994,"lng"=>2.35419,"data"=>array("drive"=>false,"zip"=>75010,"city"=>"PARIS")),
  array("lat"=>48.87709,"lng"=>2.40637,"data"=>array("drive"=>false,"zip"=>75019,"city"=>"PARIS")),
  array("lat"=>48.87594,"lng"=>2.34406,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.87536,"lng"=>2.32551,"data"=>array("drive"=>false,"zip"=>75008,"city"=>"PARIS")),
  array("lat"=>48.87541,"lng"=>2.29615,"data"=>array("drive"=>false,"zip"=>75017,"city"=>"PARIS")),
  array("lat"=>48.87421,"lng"=>2.32953,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.87248,"lng"=>2.29907,"data"=>array("drive"=>false,"zip"=>75008,"city"=>"PARIS")),
  array("lat"=>48.87196,"lng"=>2.3403,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.8712,"lng"=>2.33522,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.87119,"lng"=>2.30334,"data"=>array("drive"=>false,"zip"=>75008,"city"=>"PARIS")),
  array("lat"=>48.8707,"lng"=>2.34771,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.86912,"lng"=>2.35408,"data"=>array("drive"=>false,"zip"=>75002,"city"=>"PARIS")),
  array("lat"=>48.86889,"lng"=>2.36774,"data"=>array("drive"=>false,"zip"=>75010,"city"=>"PARIS")),
  array("lat"=>48.86493,"lng"=>2.3748,"data"=>array("drive"=>false,"zip"=>75011,"city"=>"PARIS")),
  array("lat"=>48.86328,"lng"=>2.33356,"data"=>array("drive"=>false,"zip"=>75001,"city"=>"PARIS")),
  array("lat"=>48.86085,"lng"=>2.34816,"data"=>array("drive"=>false,"zip"=>75001,"city"=>"PARIS")),
  array("lat"=>48.8592,"lng"=>2.346,"data"=>array("drive"=>false,"zip"=>75001,"city"=>"PARIS")),
  array("lat"=>48.88347,"lng"=>2.32782,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.88244,"lng"=>2.33784,"data"=>array("drive"=>false,"zip"=>75018,"city"=>"PARIS")),
  array("lat"=>48.85756,"lng"=>2.38052,"data"=>array("drive"=>false,"zip"=>75011,"city"=>"PARIS")),
  array("lat"=>48.85783,"lng"=>2.35159,"data"=>array("drive"=>false,"zip"=>75004,"city"=>"PARIS")),
  array("lat"=>48.8533,"lng"=>2.41056,"data"=>array("drive"=>false,"zip"=>75020,"city"=>"PARIS")),
  array("lat"=>48.85128,"lng"=>2.34368,"data"=>array("drive"=>false,"zip"=>75005,"city"=>"PARIS")),
  array("lat"=>48.84883,"lng"=>2.29764,"data"=>array("drive"=>false,"zip"=>75015,"city"=>"PARIS")),
  array("lat"=>48.84741,"lng"=>2.41095,"data"=>array("drive"=>false,"zip"=>75020,"city"=>"PARIS")),
  array("lat"=>48.84456,"lng"=>2.32456,"data"=>array("drive"=>false,"zip"=>75006,"city"=>"PARIS")),
  array("lat"=>48.83804,"lng"=>2.2577,"data"=>array("drive"=>false,"zip"=>75016,"city"=>"PARIS")),
  array("lat"=>48.83751,"lng"=>2.29565,"data"=>array("drive"=>false,"zip"=>75015,"city"=>"PARIS")),
  array("lat"=>48.83658,"lng"=>2.35109,"data"=>array("drive"=>false,"zip"=>75013,"city"=>"PARIS")),
  array("lat"=>48.83572,"lng"=>2.40603,"data"=>array("drive"=>false,"zip"=>75012,"city"=>"PARIS")),
  array("lat"=>48.83334,"lng"=>2.3316,"data"=>array("drive"=>false,"zip"=>75014,"city"=>"PARIS")),
  array("lat"=>48.82689,"lng"=>2.36655,"data"=>array("drive"=>false,"zip"=>75013,"city"=>"PARIS")),
  array("lat"=>48.82605,"lng"=>2.35726,"data"=>array("drive"=>false,"zip"=>75013,"city"=>"PARIS")),
  array("lat"=>48.93437,"lng"=>2.33282,"data"=>array("drive"=>false,"zip"=>92390,"city"=>"VILLENEUVE-LA-GARENNE")),
  array("lat"=>48.92315,"lng"=>2.25454,"data"=>array("drive"=>false,"zip"=>92700,"city"=>"COLOMBES")),
  array("lat"=>48.91072,"lng"=>2.23447,"data"=>array("drive"=>true,"zip"=>92700,"city"=>"COLOMBES")),
  array("lat"=>48.90288,"lng"=>2.30386,"data"=>array("drive"=>false,"zip"=>92110,"city"=>"CLICHY")),
  array("lat"=>48.90125,"lng"=>2.22537,"data"=>array("drive"=>true,"zip"=>92000,"city"=>"NANTERRE")),
  array("lat"=>48.89606,"lng"=>2.24884,"data"=>array("drive"=>false,"zip"=>92400,"city"=>"COURBEVOIE")),
  array("lat"=>48.89148,"lng"=>2.29092,"data"=>array("drive"=>false,"zip"=>92300,"city"=>"LEVALLOIS-PERRET")),
  array("lat"=>48.89108,"lng"=>2.23207,"data"=>array("drive"=>false,"zip"=>92800,"city"=>"PUTEAUX")),
  array("lat"=>48.88512,"lng"=>2.1951,"data"=>array("drive"=>true,"zip"=>92000,"city"=>"NANTERRE")),
  array("lat"=>48.88182,"lng"=>2.23904,"data"=>array("drive"=>false,"zip"=>92800,"city"=>"PUTEAUX")),
  array("lat"=>48.88134,"lng"=>2.27211,"data"=>array("drive"=>false,"zip"=>92200,"city"=>"NEUILLY-SUR-SEINE")),
  array("lat"=>48.8705,"lng"=>2.22708,"data"=>array("drive"=>false,"zip"=>92150,"city"=>"SURESNES")),
  array("lat"=>48.83383,"lng"=>2.24339,"data"=>array("drive"=>false,"zip"=>92100,"city"=>"BOULOGNE-BILLANCOURT")),
  array("lat"=>48.82697,"lng"=>2.2787,"data"=>array("drive"=>false,"zip"=>92130,"city"=>"ISSY-LES-MOULINEAUX")),
  array("lat"=>48.8243,"lng"=>2.29862,"data"=>array("drive"=>false,"zip"=>92170,"city"=>"VANVES")),
  array("lat"=>48.82224,"lng"=>2.20664,"data"=>array("drive"=>false,"zip"=>92310,"city"=>"SÈVRES")),
  array("lat"=>48.82085,"lng"=>2.25049,"data"=>array("drive"=>false,"zip"=>92130,"city"=>"ISSY-LES-MOULINEAUX")),
  array("lat"=>48.80793,"lng"=>2.29534,"data"=>array("drive"=>true,"zip"=>92320,"city"=>"CHÂTILLON")),
  array("lat"=>48.78709,"lng"=>2.25559,"data"=>array("drive"=>true,"zip"=>92140,"city"=>"CLAMART")),
  array("lat"=>48.91406,"lng"=>2.22959,"data"=>array("drive"=>false,"zip"=>92700,"city"=>"COLOMBES")),
  array("lat"=>48.93868,"lng"=>2.30433,"data"=>array("drive"=>false,"zip"=>92230,"city"=>"GENNEVILLIERS")),
  array("lat"=>48.86126,"lng"=>2.34792,"data"=>array("drive"=>false,"zip"=>75001,"city"=>"PARIS")),
  array("lat"=>48.75413,"lng"=>2.30133,"data"=>array("drive"=>false,"zip"=>92160,"city"=>"ANTONY")),
  array("lat"=>48.9317,"lng"=>2.28164,"data"=>array("drive"=>true,"zip"=>92600,"city"=>"ASNIÈRES-SUR-SEINE")),
  array("lat"=>48.87545,"lng"=>2.32846,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.85746,"lng"=>2.27758,"data"=>array("drive"=>false,"zip"=>75016,"city"=>"PARIS")),
  array("lat"=>48.82844,"lng"=>2.32741,"data"=>array("drive"=>false,"zip"=>75014,"city"=>"PARIS")),
  array("lat"=>48.86797,"lng"=>2.28143,"data"=>array("drive"=>false,"zip"=>75116,"city"=>"PARIS")),
  array("lat"=>48.847,"lng"=>2.28514,"data"=>array("drive"=>false,"zip"=>75015,"city"=>"PARIS")),
  array("lat"=>48.88388,"lng"=>2.47452,"data"=>array("drive"=>true,"zip"=>93110,"city"=>"ROSNY-SOUS-BOIS")),
  array("lat"=>48.86543,"lng"=>2.41724,"data"=>array("drive"=>false,"zip"=>93170,"city"=>"BAGNOLET")),
  array("lat"=>48.8513,"lng"=>2.3761,"data"=>array("drive"=>false,"zip"=>75012,"city"=>"PARIS")),
  array("lat"=>48.84877,"lng"=>2.57829,"data"=>array("drive"=>true,"zip"=>77420,"city"=>"CHAMPS-SUR-MARNE")),
  array("lat"=>48.82909,"lng"=>2.74287,"data"=>array("drive"=>false,"zip"=>77600,"city"=>"BUSSY-SAINT-GEORGES")),
  array("lat"=>48.77783,"lng"=>2.60701,"data"=>array("drive"=>false,"zip"=>77340,"city"=>"PONTAULT-COMBAULT")),
  array("lat"=>48.70231,"lng"=>2.59736,"data"=>array("drive"=>true,"zip"=>77170,"city"=>"BRIE-COMTE-ROBERT")),
  array("lat"=>48.87035,"lng"=>2.68225,"data"=>array("drive"=>true,"zip"=>77400,"city"=>"LAGNY-SUR-MARNE")),
  array("lat"=>48.99743,"lng"=>1.90877,"data"=>array("drive"=>true,"zip"=>78130,"city"=>"LES MUREAUX")),
  array("lat"=>48.98845,"lng"=>1.71233,"data"=>array("drive"=>false,"zip"=>78200,"city"=>"MANTES-LA-JOLIE")),
  array("lat"=>48.9801,"lng"=>1.69566,"data"=>array("drive"=>true,"zip"=>78711,"city"=>"MANTES-LA-VILLE")),
  array("lat"=>48.93822,"lng"=>2.17054,"data"=>array("drive"=>true,"zip"=>78500,"city"=>"SARTROUVILLE")),
  array("lat"=>48.92896,"lng"=>2.04337,"data"=>array("drive"=>false,"zip"=>78300,"city"=>"POISSY")),
  array("lat"=>48.90527,"lng"=>2.11544,"data"=>array("drive"=>true,"zip"=>78360,"city"=>"MONTESSON")),
  array("lat"=>48.89813,"lng"=>2.09442,"data"=>array("drive"=>false,"zip"=>78100,"city"=>"SAINT-GERMAIN-EN-LAYE")),
  array("lat"=>48.89754,"lng"=>2.08901,"data"=>array("drive"=>false,"zip"=>78100,"city"=>"SAINT-GERMAIN-EN-LAYE")),
  array("lat"=>48.85926,"lng"=>2.14864,"data"=>array("drive"=>false,"zip"=>78170,"city"=>"LA CELLE-SAINT-CLOUD")),
  array("lat"=>48.82707,"lng"=>2.11734,"data"=>array("drive"=>false,"zip"=>78150,"city"=>"LE CHESNAY")),
  array("lat"=>48.80057,"lng"=>2.12864,"data"=>array("drive"=>false,"zip"=>78000,"city"=>"VERSAILLES")),
  array("lat"=>48.79309,"lng"=>2.14364,"data"=>array("drive"=>false,"zip"=>78000,"city"=>"VERSAILLES")),
  array("lat"=>48.78257,"lng"=>2.04252,"data"=>array("drive"=>false,"zip"=>78180,"city"=>"MONTIGNY-LE-BRETONNEUX")),
  array("lat"=>48.77885,"lng"=>2.2082,"data"=>array("drive"=>true,"zip"=>78140,"city"=>"VÉLIZY-VILLACOUBLAY")),
  array("lat"=>48.76018,"lng"=>1.91805,"data"=>array("drive"=>true,"zip"=>78310,"city"=>"MAUREPAS")),
  array("lat"=>48.90958,"lng"=>2.03291,"data"=>array("drive"=>false,"zip"=>78240,"city"=>"CHAMBOURCY")),
  array("lat"=>49.02052,"lng"=>2.46554,"data"=>array("drive"=>true,"zip"=>95190,"city"=>"GOUSSAINVILLE")),
  array("lat"=>49.01884,"lng"=>2.09517,"data"=>array("drive"=>true,"zip"=>95610,"city"=>"ÉRAGNY")),
  array("lat"=>49.00025,"lng"=>2.39233,"data"=>array("drive"=>true,"zip"=>95400,"city"=>"VILLIERS-LE-BEL")),
  array("lat"=>48.99557,"lng"=>2.19194,"data"=>array("drive"=>true,"zip"=>95370,"city"=>"MONTIGNY-LÈS-CORMEILLES")),
  array("lat"=>48.99092,"lng"=>2.28967,"data"=>array("drive"=>false,"zip"=>95230,"city"=>"SOISY-SOUS-MONTMORENCY")),
  array("lat"=>48.97821,"lng"=>2.3768,"data"=>array("drive"=>false,"zip"=>95200,"city"=>"SARCELLES")),
  array("lat"=>48.9777,"lng"=>2.49891,"data"=>array("drive"=>true,"zip"=>95500,"city"=>"GONESSE")),
  array("lat"=>48.97047,"lng"=>2.30676,"data"=>array("drive"=>false,"zip"=>95880,"city"=>"ENGHIEN-LES-BAINS")),
  array("lat"=>48.9644,"lng"=>2.257,"data"=>array("drive"=>false,"zip"=>95110,"city"=>"SANNOIS")),
  array("lat"=>48.96159,"lng"=>2.40038,"data"=>array("drive"=>true,"zip"=>95140,"city"=>"GARGES-LÈS-GONESSE")),
  array("lat"=>48.94479,"lng"=>2.25198,"data"=>array("drive"=>false,"zip"=>95100,"city"=>"ARGENTEUIL")),
  array("lat"=>48.92288,"lng"=>2.21958,"data"=>array("drive"=>true,"zip"=>95870,"city"=>"BEZONS")),
  array("lat"=>49.02283,"lng"=>2.1413,"data"=>array("drive"=>true,"zip"=>95480,"city"=>"PIERRELAYE")),
  array("lat"=>48.97588,"lng"=>2.36529,"data"=>array("drive"=>true,"zip"=>95200,"city"=>"SARCELLES")),
  array("lat"=>48.72993,"lng"=>2.24129,"data"=>array("drive"=>true,"zip"=>91300,"city"=>"MASSY")),
  array("lat"=>48.71443,"lng"=>2.43924,"data"=>array("drive"=>false,"zip"=>91230,"city"=>"MONTGERON")),
  array("lat"=>48.69976,"lng"=>2.41693,"data"=>array("drive"=>true,"zip"=>91270,"city"=>"VIGNEUX-SUR-SEINE")),
  array("lat"=>48.67737,"lng"=>2.16734,"data"=>array("drive"=>false,"zip"=>91940,"city"=>"LES ULIS")),
  array("lat"=>48.67141,"lng"=>2.27707,"data"=>array("drive"=>true,"zip"=>91160,"city"=>"SAULX-LES-CHARTREUX")),
  array("lat"=>48.66971,"lng"=>2.39299,"data"=>array("drive"=>true,"zip"=>91350,"city"=>"GRIGNY")),
  array("lat"=>48.65127,"lng"=>2.27371,"data"=>array("drive"=>true,"zip"=>91310,"city"=>"MONTLHÉRY")),
  array("lat"=>48.63024,"lng"=>2.42802,"data"=>array("drive"=>true,"zip"=>91000,"city"=>"ÉVRY")),
  array("lat"=>48.63037,"lng"=>2.492,"data"=>array("drive"=>true,"zip"=>91250,"city"=>"SAINT-GERMAIN-LÈS-CORBEIL")),
  array("lat"=>48.61404,"lng"=>2.45613,"data"=>array("drive"=>true,"zip"=>91100,"city"=>"CORBEIL-ESSONNES")),
  array("lat"=>48.59452,"lng"=>2.44349,"data"=>array("drive"=>true,"zip"=>91100,"city"=>"VILLABÉ")),
  array("lat"=>48.66869,"lng"=>2.33784,"data"=>array("drive"=>true,"zip"=>91360,"city"=>"ÉPINAY-SUR-ORGE")),
  array("lat"=>48.82629,"lng"=>1.96407,"data"=>array("drive"=>true,"zip"=>78370,"city"=>"PLAISIR")),
  array("lat"=>48.84318,"lng"=>2.36413,"data"=>array("drive"=>false,"zip"=>75005,"city"=>"PARIS")),
  array("lat"=>48.84714,"lng"=>2.34075,"data"=>array("drive"=>false,"zip"=>75005,"city"=>"PARIS")),
  array("lat"=>48.87644,"lng"=>2.35586,"data"=>array("drive"=>false,"zip"=>75010,"city"=>"PARIS")),
  array("lat"=>49.41181,"lng"=>0.25174,"data"=>array("drive"=>true,"zip"=>14600,"city"=>"LA RIVIÈRE-SAINT-SAUVEUR")),
  array("lat"=>49.4737,"lng"=>1.11263,"data"=>array("drive"=>false,"zip"=>76230,"city"=>"BOIS-GUILLAUME")),
  array("lat"=>49.44202,"lng"=>1.09018,"data"=>array("drive"=>false,"zip"=>76000,"city"=>"ROUEN")),
  array("lat"=>49.4311,"lng"=>1.08635,"data"=>array("drive"=>false,"zip"=>76100,"city"=>"ROUEN")),
  array("lat"=>49.41436,"lng"=>1.04467,"data"=>array("drive"=>true,"zip"=>76120,"city"=>"LE GRAND-QUEVILLY")),
  array("lat"=>49.40847,"lng"=>1.14557,"data"=>array("drive"=>false,"zip"=>76240,"city"=>"LE MESNIL-ESNARD")),
  array("lat"=>47.87932,"lng"=>1.90859,"data"=>array("drive"=>true,"zip"=>45100,"city"=>"ORLÉANS")),
  array("lat"=>47.90645,"lng"=>1.90394,"data"=>array("drive"=>false,"zip"=>45000,"city"=>"ORLÉANS")),
  array("lat"=>47.28396,"lng"=>-1.55241,"data"=>array("drive"=>true,"zip"=>44240,"city"=>"LA CHAPELLE-SUR-ERDRE")),
  array("lat"=>47.26103,"lng"=>-1.58239,"data"=>array("drive"=>true,"zip"=>44300,"city"=>"NANTES")),
  array("lat"=>47.25693,"lng"=>-1.51066,"data"=>array("drive"=>true,"zip"=>44300,"city"=>"NANTES")),
  array("lat"=>47.21379,"lng"=>-1.55804,"data"=>array("drive"=>false,"zip"=>44000,"city"=>"NANTES")),
  array("lat"=>47.19756,"lng"=>-1.61669,"data"=>array("drive"=>true,"zip"=>44100,"city"=>"NANTES")),
  array("lat"=>47.39644,"lng"=>-0.52917,"data"=>array("drive"=>true,"zip"=>49610,"city"=>"MÛRS-ERIGNÉ")),
  array("lat"=>47.46989,"lng"=>-0.54842,"data"=>array("drive"=>false,"zip"=>49100,"city"=>"ANGERS")),
  array("lat"=>47.45027,"lng"=>-0.55598,"data"=>array("drive"=>true,"zip"=>49000,"city"=>"ANGERS")),
  array("lat"=>47.42584,"lng"=>0.70218,"data"=>array("drive"=>true,"zip"=>37100,"city"=>"TOURS")),
  array("lat"=>47.38962,"lng"=>0.6928,"data"=>array("drive"=>false,"zip"=>37000,"city"=>"TOURS")),
  array("lat"=>48.40519,"lng"=>0.08762,"data"=>array("drive"=>true,"zip"=>72610,"city"=>"ARÇONNAY")),
  array("lat"=>49.1466,"lng"=>-0.33931,"data"=>array("drive"=>true,"zip"=>14123,"city"=>"IFS")),
  array("lat"=>49.16351,"lng"=>-0.29704,"data"=>array("drive"=>true,"zip"=>14120,"city"=>"MONDEVILLE")),
  array("lat"=>49.20971,"lng"=>-0.36198,"data"=>array("drive"=>true,"zip"=>14000,"city"=>"CAEN")),
  array("lat"=>49.18311,"lng"=>-0.36157,"data"=>array("drive"=>false,"zip"=>14000,"city"=>"CAEN")),
  array("lat"=>49.20657,"lng"=>-0.32572,"data"=>array("drive"=>false,"zip"=>14200,"city"=>"HÉROUVILLE-SAINT-CLAIR")),
  array("lat"=>48.39935,"lng"=>-4.40702,"data"=>array("drive"=>true,"zip"=>29480,"city"=>"LE RELECQ-KERHUON")),
  array("lat"=>48.42647,"lng"=>-4.57174,"data"=>array("drive"=>true,"zip"=>29820,"city"=>"GUILERS")),
  array("lat"=>48.41544,"lng"=>-4.46825,"data"=>array("drive"=>true,"zip"=>29200,"city"=>"BREST")),
  array("lat"=>48.38801,"lng"=>-4.52839,"data"=>array("drive"=>true,"zip"=>29200,"city"=>"BREST")),
  array("lat"=>48.39267,"lng"=>-4.48221,"data"=>array("drive"=>false,"zip"=>29200,"city"=>"BREST")),
  array("lat"=>48.03644,"lng"=>0.1757,"data"=>array("drive"=>true,"zip"=>72650,"city"=>"LA CHAPELLE-SAINT-AUBIN")),
  array("lat"=>48.00412,"lng"=>0.19587,"data"=>array("drive"=>false,"zip"=>72000,"city"=>"LE MANS")),
  array("lat"=>44.77157,"lng"=>-1.11411,"data"=>array("drive"=>true,"zip"=>33740,"city"=>"ARÈS")),
  array("lat"=>43.68956,"lng"=>4.2069,"data"=>array("drive"=>true,"zip"=>30470,"city"=>"AIMARGUES")),
  array("lat"=>44.91112,"lng"=>-0.6245,"data"=>array("drive"=>true,"zip"=>33290,"city"=>"BLANQUEFORT")),
  array("lat"=>44.89244,"lng"=>-0.66529,"data"=>array("drive"=>true,"zip"=>33320,"city"=>"EYSINES")),
  array("lat"=>44.86625,"lng"=>-0.51428,"data"=>array("drive"=>true,"zip"=>33310,"city"=>"LORMONT")),
  array("lat"=>44.85368,"lng"=>-0.59361,"data"=>array("drive"=>false,"zip"=>33110,"city"=>"LE BOUSCAT")),
  array("lat"=>44.842,"lng"=>-0.55719,"data"=>array("drive"=>false,"zip"=>33100,"city"=>"BORDEAUX")),
  array("lat"=>44.82949,"lng"=>-0.59558,"data"=>array("drive"=>true,"zip"=>33000,"city"=>"BORDEAUX")),
  array("lat"=>44.81414,"lng"=>-0.57285,"data"=>array("drive"=>true,"zip"=>33800,"city"=>"BORDEAUX")),
  array("lat"=>45.77804,"lng"=>3.08178,"data"=>array("drive"=>false,"zip"=>63000,"city"=>"CLERMONT-FERRAND")),
  array("lat"=>45.74048,"lng"=>3.17328,"data"=>array("drive"=>true,"zip"=>63800,"city"=>"COURNON-D'AUVERGNE")),
  array("lat"=>45.77614,"lng"=>3.18608,"data"=>array("drive"=>true,"zip"=>63370,"city"=>"LEMPDES")),
  array("lat"=>43.64129,"lng"=>3.94293,"data"=>array("drive"=>true,"zip"=>34920,"city"=>"LE CRÈS")),
  array("lat"=>43.62186,"lng"=>3.81443,"data"=>array("drive"=>false,"zip"=>34080,"city"=>"MONTPELLIER")),
  array("lat"=>43.60865,"lng"=>3.87935,"data"=>array("drive"=>false,"zip"=>34000,"city"=>"MONTPELLIER")),
  array("lat"=>43.58907,"lng"=>3.85653,"data"=>array("drive"=>true,"zip"=>34070,"city"=>"MONTPELLIER")),
  array("lat"=>43.52062,"lng"=>1.49658,"data"=>array("drive"=>true,"zip"=>31320,"city"=>"CASTANET-TOLOSAN")),
  array("lat"=>43.56444,"lng"=>1.51494,"data"=>array("drive"=>true,"zip"=>31650,"city"=>"SAINT-ORENS-DE-GAMEVILLE")),
  array("lat"=>43.64576,"lng"=>1.47168,"data"=>array("drive"=>true,"zip"=>31240,"city"=>"L'UNION")),
  array("lat"=>43.60795,"lng"=>1.39494,"data"=>array("drive"=>true,"zip"=>31300,"city"=>"TOULOUSE")),
  array("lat"=>43.60487,"lng"=>1.44326,"data"=>array("drive"=>false,"zip"=>31000,"city"=>"TOULOUSE")),
  array("lat"=>43.58936,"lng"=>1.35926,"data"=>array("drive"=>true,"zip"=>31170,"city"=>"TOURNEFEUILLE")),
  array("lat"=>43.61313,"lng"=>1.33044,"data"=>array("drive"=>true,"zip"=>31770,"city"=>"COLOMIERS")),
  array("lat"=>43.6109,"lng"=>1.43643,"data"=>array("drive"=>false,"zip"=>31000,"city"=>"TOULOUSE")),
  array("lat"=>43.85682,"lng"=>4.40565,"data"=>array("drive"=>true,"zip"=>30900,"city"=>"NÎMES")),
  array("lat"=>42.71726,"lng"=>2.8876,"data"=>array("drive"=>true,"zip"=>66000,"city"=>"PERPIGNAN")),
  array("lat"=>43.318,"lng"=>-0.42416,"data"=>array("drive"=>true,"zip"=>64140,"city"=>"LONS")),
  array("lat"=>45.87995,"lng"=>1.29063,"data"=>array("drive"=>true,"zip"=>87280,"city"=>"LIMOGES")),
  array("lat"=>45.84888,"lng"=>1.24516,"data"=>array("drive"=>false,"zip"=>87100,"city"=>"LIMOGES")),
  array("lat"=>45.81015,"lng"=>1.26002,"data"=>array("drive"=>false,"zip"=>87000,"city"=>"LIMOGES")),
  array("lat"=>43.51822,"lng"=>5.43421,"data"=>array("drive"=>true,"zip"=>13090,"city"=>"AIX-EN-PROVENCE")),
  array("lat"=>43.50479,"lng"=>5.39378,"data"=>array("drive"=>false,"zip"=>13290,"city"=>"AIX-EN-PROVENCE")),
  array("lat"=>43.44053,"lng"=>5.24325,"data"=>array("drive"=>false,"zip"=>13127,"city"=>"VITROLLES")),
  array("lat"=>43.43115,"lng"=>5.264,"data"=>array("drive"=>true,"zip"=>13127,"city"=>"VITROLLES")),
  array("lat"=>43.33113,"lng"=>5.38912,"data"=>array("drive"=>true,"zip"=>13014,"city"=>"MARSEILLE")),
  array("lat"=>43.30165,"lng"=>5.37477,"data"=>array("drive"=>false,"zip"=>13003,"city"=>"MARSEILLE")),
  array("lat"=>43.29421,"lng"=>5.37434,"data"=>array("drive"=>false,"zip"=>13001,"city"=>"MARSEILLE")),
  array("lat"=>43.29323,"lng"=>5.37849,"data"=>array("drive"=>false,"zip"=>13001,"city"=>"MARSEILLE")),
  array("lat"=>43.28696,"lng"=>5.38321,"data"=>array("drive"=>false,"zip"=>13006,"city"=>"MARSEILLE")),
  array("lat"=>43.24887,"lng"=>5.39094,"data"=>array("drive"=>false,"zip"=>13008,"city"=>"MARSEILLE")),
  array("lat"=>43.3038,"lng"=>5.38659,"data"=>array("drive"=>false,"zip"=>13001,"city"=>"MARSEILLE")),
  array("lat"=>43.48742,"lng"=>5.37842,"data"=>array("drive"=>false,"zip"=>13290,"city"=>"AIX-EN-PROVENCE")),
  array("lat"=>43.30302,"lng"=>5.40138,"data"=>array("drive"=>true,"zip"=>13004,"city"=>"MARSEILLE")),
  array("lat"=>45.77238,"lng"=>4.97641,"data"=>array("drive"=>true,"zip"=>69150,"city"=>"DÉCINES-CHARPIEU")),
  array("lat"=>45.76433,"lng"=>4.83426,"data"=>array("drive"=>false,"zip"=>69002,"city"=>"LYON")),
  array("lat"=>45.75281,"lng"=>4.82899,"data"=>array("drive"=>false,"zip"=>69002,"city"=>"LYON")),
  array("lat"=>45.74315,"lng"=>4.87811,"data"=>array("drive"=>false,"zip"=>69008,"city"=>"LYON")),
  array("lat"=>45.68471,"lng"=>4.94752,"data"=>array("drive"=>true,"zip"=>69800,"city"=>"SAINT-PRIEST")),
  array("lat"=>45.7582,"lng"=>4.83433,"data"=>array("drive"=>false,"zip"=>69002,"city"=>"LYON")),
  array("lat"=>45.74819,"lng"=>4.93192,"data"=>array("drive"=>true,"zip"=>69120,"city"=>"VAULX-EN-VELIN")),
  array("lat"=>45.75523,"lng"=>4.84282,"data"=>array("drive"=>false,"zip"=>69007,"city"=>"LYON")),
  array("lat"=>43.41939,"lng"=>5.22989,"data"=>array("drive"=>true,"zip"=>13730,"city"=>"SAINT-VICTORET")),
  array("lat"=>43.77513,"lng"=>7.50518,"data"=>array("drive"=>false,"zip"=>6500,"city"=>"MENTON")),
  array("lat"=>43.70545,"lng"=>7.2846,"data"=>array("drive"=>false,"zip"=>6300,"city"=>"NICE")),
  array("lat"=>43.7003,"lng"=>7.26831,"data"=>array("drive"=>false,"zip"=>6000,"city"=>"NICE")),
  array("lat"=>43.65347,"lng"=>7.15638,"data"=>array("drive"=>false,"zip"=>6800,"city"=>"CAGNES-SUR-MER")),
  array("lat"=>43.64529,"lng"=>6.94107,"data"=>array("drive"=>true,"zip"=>6130,"city"=>"GRASSE")),
  array("lat"=>43.57644,"lng"=>7.05642,"data"=>array("drive"=>true,"zip"=>6220,"city"=>"VALLAURIS")),
  array("lat"=>43.57408,"lng"=>7.09028,"data"=>array("drive"=>true,"zip"=>6160,"city"=>"ANTIBES")),
  array("lat"=>43.55089,"lng"=>6.95699,"data"=>array("drive"=>false,"zip"=>6150,"city"=>"CANNES")),
  array("lat"=>43.66216,"lng"=>7.13065,"data"=>array("drive"=>true,"zip"=>6800,"city"=>"CAGNES-SUR-MER")),
  array("lat"=>45.19641,"lng"=>5.67465,"data"=>array("drive"=>true,"zip"=>38600,"city"=>"FONTAINE")),
  array("lat"=>45.1903,"lng"=>5.72659,"data"=>array("drive"=>false,"zip"=>38000,"city"=>"GRENOBLE")),
  array("lat"=>45.14931,"lng"=>5.69424,"data"=>array("drive"=>true,"zip"=>38130,"city"=>"ÉCHIROLLES")),
  array("lat"=>45.15736,"lng"=>5.73375,"data"=>array("drive"=>false,"zip"=>38100,"city"=>"GRENOBLE")),
  array("lat"=>45.18462,"lng"=>5.7676,"data"=>array("drive"=>true,"zip"=>38400,"city"=>"SAINT-MARTIN-D'HÈRES")),
  array("lat"=>45.15025,"lng"=>5.71702,"data"=>array("drive"=>true,"zip"=>38130,"city"=>"ÉCHIROLLES")),
  array("lat"=>45.43618,"lng"=>4.38803,"data"=>array("drive"=>false,"zip"=>42000,"city"=>"SAINT-ÉTIENNE")),
  array("lat"=>45.42353,"lng"=>4.39379,"data"=>array("drive"=>false,"zip"=>42100,"city"=>"SAINT-ÉTIENNE")),
  array("lat"=>45.48132,"lng"=>4.44218,"data"=>array("drive"=>true,"zip"=>42290,"city"=>"SORBIERS")),
  array("lat"=>43.1227,"lng"=>5.88117,"data"=>array("drive"=>true,"zip"=>83190,"city"=>"OLLIOULES")),
  array("lat"=>43.10498,"lng"=>5.81715,"data"=>array("drive"=>true,"zip"=>83140,"city"=>"SIX-FOURS-LES-PLAGES")),
  array("lat"=>43.13913,"lng"=>6.0352,"data"=>array("drive"=>false,"zip"=>83130,"city"=>"LA GARDE")),
  array("lat"=>43.13774,"lng"=>6.02171,"data"=>array("drive"=>true,"zip"=>83130,"city"=>"LA GARDE")),
  array("lat"=>43.12102,"lng"=>5.94259,"data"=>array("drive"=>false,"zip"=>83000,"city"=>"TOULON")),
  array("lat"=>43.1194,"lng"=>6.12861,"data"=>array("drive"=>true,"zip"=>83400,"city"=>"HYÈRES")),
  array("lat"=>43.12503,"lng"=>5.93188,"data"=>array("drive"=>false,"zip"=>83000,"city"=>"TOULON")),
  array("lat"=>43.10874,"lng"=>5.85783,"data"=>array("drive"=>true,"zip"=>83500,"city"=>"LA SEYNE-SUR-MER")),
  array("lat"=>43.10896,"lng"=>6.03628,"data"=>array("drive"=>true,"zip"=>83220,"city"=>"LE PRADET")),
  array("lat"=>43.27084,"lng"=>5.40045,"data"=>array("drive"=>true,"zip"=>13009,"city"=>"MARSEILLE")),
  array("lat"=>45.76004,"lng"=>5.02856,"data"=>array("drive"=>true,"zip"=>69330,"city"=>"MEYZIEU")),
  array("lat"=>45.74909,"lng"=>4.86088,"data"=>array("drive"=>false,"zip"=>69008,"city"=>"LYON")),
  array("lat"=>45.75176,"lng"=>4.77025,"data"=>array("drive"=>true,"zip"=>69160,"city"=>"TASSIN-LA-DEMI-LUNE")),
  array("lat"=>45.72414,"lng"=>4.93567,"data"=>array("drive"=>true,"zip"=>69800,"city"=>"SAINT-PRIEST")),
  array("lat"=>46.91009,"lng"=>6.33372,"data"=>array("drive"=>true,"zip"=>25300,"city"=>"PONTARLIER")),
  array("lat"=>50.73893,"lng"=>3.14759,"data"=>array("drive"=>true,"zip"=>59200,"city"=>"TOURCOING")),
  array("lat"=>50.72609,"lng"=>3.13375,"data"=>array("drive"=>true,"zip"=>59200,"city"=>"TOURCOING")),
  array("lat"=>50.68214,"lng"=>3.21482,"data"=>array("drive"=>true,"zip"=>59390,"city"=>"LYS-LEZ-LANNOY")),
  array("lat"=>50.66946,"lng"=>3.1546,"data"=>array("drive"=>true,"zip"=>59170,"city"=>"CROIX")),
  array("lat"=>50.66523,"lng"=>3.07593,"data"=>array("drive"=>false,"zip"=>59700,"city"=>"MARCQ-EN-BAROEUL")),
  array("lat"=>50.63701,"lng"=>3.06287,"data"=>array("drive"=>false,"zip"=>59000,"city"=>"LILLE")),
  array("lat"=>50.63575,"lng"=>3.0703,"data"=>array("drive"=>false,"zip"=>59000,"city"=>"LILLE")),
  array("lat"=>50.63265,"lng"=>3.06234,"data"=>array("drive"=>false,"zip"=>59000,"city"=>"LILLE")),
  array("lat"=>50.61884,"lng"=>3.03446,"data"=>array("drive"=>true,"zip"=>59000,"city"=>"LILLE")),
  array("lat"=>50.61702,"lng"=>3.12719,"data"=>array("drive"=>true,"zip"=>59650,"city"=>"VILLENEUVE-D'ASCQ")),
  array("lat"=>50.59705,"lng"=>3.05114,"data"=>array("drive"=>true,"zip"=>59139,"city"=>"WATTIGNIES")),
  array("lat"=>50.54859,"lng"=>3.04976,"data"=>array("drive"=>true,"zip"=>59113,"city"=>"SECLIN")),
  array("lat"=>50.72305,"lng"=>3.15847,"data"=>array("drive"=>false,"zip"=>59200,"city"=>"TOURCOING")),
  array("lat"=>50.65121,"lng"=>2.98407,"data"=>array("drive"=>true,"zip"=>59160,"city"=>"LILLE")),
  array("lat"=>48.6311,"lng"=>7.76446,"data"=>array("drive"=>false,"zip"=>67800,"city"=>"HOENHEIM")),
  array("lat"=>48.59165,"lng"=>7.67184,"data"=>array("drive"=>true,"zip"=>67202,"city"=>"WOLFISHEIM")),
  array("lat"=>48.58771,"lng"=>7.74123,"data"=>array("drive"=>false,"zip"=>67000,"city"=>"STRASBOURG")),
  array("lat"=>48.58443,"lng"=>7.73639,"data"=>array("drive"=>false,"zip"=>67000,"city"=>"STRASBOURG")),
  array("lat"=>48.5831,"lng"=>7.74694,"data"=>array("drive"=>false,"zip"=>67000,"city"=>"STRASBOURG")),
  array("lat"=>48.56168,"lng"=>7.75217,"data"=>array("drive"=>false,"zip"=>67100,"city"=>"STRASBOURG")),
  array("lat"=>48.52916,"lng"=>7.73188,"data"=>array("drive"=>true,"zip"=>67400,"city"=>"ILLKIRCH-GRAFFENSTADEN")),
  array("lat"=>50.38203,"lng"=>3.47714,"data"=>array("drive"=>true,"zip"=>59494,"city"=>"PETITE-FORÊT")),
  array("lat"=>50.36454,"lng"=>3.52201,"data"=>array("drive"=>true,"zip"=>59300,"city"=>"VALENCIENNES")),
  array("lat"=>50.32622,"lng"=>3.3878,"data"=>array("drive"=>true,"zip"=>59220,"city"=>"DENAIN")),
  array("lat"=>47.7753,"lng"=>7.39056,"data"=>array("drive"=>true,"zip"=>68390,"city"=>"SAUSHEIM")),
  array("lat"=>47.75106,"lng"=>7.33824,"data"=>array("drive"=>false,"zip"=>68200,"city"=>"MULHOUSE")),
  array("lat"=>47.74827,"lng"=>7.33908,"data"=>array("drive"=>false,"zip"=>68100,"city"=>"MULHOUSE")),
  array("lat"=>47.73373,"lng"=>7.31693,"data"=>array("drive"=>true,"zip"=>68200,"city"=>"MULHOUSE")),
  array("lat"=>47.78963,"lng"=>7.31713,"data"=>array("drive"=>true,"zip"=>68260,"city"=>"KINGERSHEIM")),
  array("lat"=>48.70113,"lng"=>6.22409,"data"=>array("drive"=>true,"zip"=>54270,"city"=>"ESSEY-LÈS-NANCY")),
  array("lat"=>48.68996,"lng"=>6.18311,"data"=>array("drive"=>false,"zip"=>54000,"city"=>"NANCY")),
  array("lat"=>48.67955,"lng"=>6.19864,"data"=>array("drive"=>true,"zip"=>54000,"city"=>"NANCY")),
  array("lat"=>48.66614,"lng"=>6.16584,"data"=>array("drive"=>true,"zip"=>54500,"city"=>"VANDOEUVRE-LÈS-NANCY")),
  array("lat"=>47.28046,"lng"=>5.01658,"data"=>array("drive"=>true,"zip"=>21160,"city"=>"MARSANNAY-LA-CÔTE")),
  array("lat"=>47.31325,"lng"=>5.09206,"data"=>array("drive"=>true,"zip"=>21800,"city"=>"QUETIGNY")),
  array("lat"=>47.32242,"lng"=>5.03715,"data"=>array("drive"=>false,"zip"=>21000,"city"=>"DIJON")),
  array("lat"=>47.31505,"lng"=>5.0642,"data"=>array("drive"=>false,"zip"=>21000,"city"=>"DIJON")),
  array("lat"=>49.2167,"lng"=>4.0508,"data"=>array("drive"=>true,"zip"=>51350,"city"=>"CORMONTREUIL")),
  array("lat"=>49.27775,"lng"=>4.0042,"data"=>array("drive"=>true,"zip"=>51100,"city"=>"REIMS")),
  array("lat"=>49.25368,"lng"=>3.97969,"data"=>array("drive"=>true,"zip"=>51430,"city"=>"TINQUEUX")),
  array("lat"=>49.26532,"lng"=>4.06005,"data"=>array("drive"=>true,"zip"=>51100,"city"=>"REIMS")),
  array("lat"=>49.25418,"lng"=>4.03032,"data"=>array("drive"=>false,"zip"=>51100,"city"=>"REIMS")),
  array("lat"=>49.23996,"lng"=>4.01363,"data"=>array("drive"=>true,"zip"=>51100,"city"=>"REIMS")),
  array("lat"=>49.11859,"lng"=>6.17494,"data"=>array("drive"=>false,"zip"=>57000,"city"=>"METZ")),
  array("lat"=>49.11473,"lng"=>6.17326,"data"=>array("drive"=>false,"zip"=>57000,"city"=>"METZ")),
  array("lat"=>49.10777,"lng"=>6.22552,"data"=>array("drive"=>true,"zip"=>57070,"city"=>"METZ")),
  array("lat"=>51.0324,"lng"=>2.39443,"data"=>array("drive"=>true,"zip"=>59240,"city"=>"DUNKERQUE")),
  array("lat"=>51.02282,"lng"=>2.31159,"data"=>array("drive"=>true,"zip"=>59760,"city"=>"GRANDE-SYNTHE")),
  array("lat"=>49.90688,"lng"=>2.31848,"data"=>array("drive"=>true,"zip"=>80080,"city"=>"AMIENS")),
  array("lat"=>49.35822,"lng"=>6.13877,"data"=>array("drive"=>true,"zip"=>57100,"city"=>"THIONVILLE")),
  array("lat"=>49.35506,"lng"=>6.13948,"data"=>array("drive"=>false,"zip"=>57100,"city"=>"THIONVILLE")),
  array("lat"=>50.3803,"lng"=>3.08867,"data"=>array("drive"=>false,"zip"=>59500,"city"=>"DOUAI")),
  array("lat"=>50.52133,"lng"=>2.79394,"data"=>array("drive"=>true,"zip"=>62138,"city"=>"AUCHY-LES-MINES")),
  array("lat"=>50.46319,"lng"=>2.82753,"data"=>array("drive"=>true,"zip"=>62880,"city"=>"VENDIN-LE-VIEIL")),
  array("lat"=>50.41626,"lng"=>2.97705,"data"=>array("drive"=>true,"zip"=>62950,"city"=>"NOYELLES-GODAULT")),
  array("lat"=>50.42277,"lng"=>2.77774,"data"=>array("drive"=>true,"zip"=>62800,"city"=>"LIÉVIN")),
  array("lat"=>48.87672,"lng"=>2.60237,"data"=>array("drive"=>true,"zip"=>77500,"city"=>"CHELLES")),
  array("lat"=>48.86453,"lng"=>2.40831,"data"=>array("drive"=>false,"zip"=>75020,"city"=>"PARIS")),
  array("lat"=>48.90676,"lng"=>2.28535,"data"=>array("drive"=>false,"zip"=>92600,"city"=>"ASNIÈRES-SUR-SEINE")),
  array("lat"=>49.01522,"lng"=>2.54222,"data"=>array("drive"=>false,"zip"=>77990,"city"=>"MAUREGARD")),
  array("lat"=>49.49603,"lng"=>0.11066,"data"=>array("drive"=>false,"zip"=>76600,"city"=>"LE HAVRE")),
  array("lat"=>47.25907,"lng"=>-2.2639,"data"=>array("drive"=>true,"zip"=>44600,"city"=>"SAINT-NAZAIRE")),
  array("lat"=>47.90554,"lng"=>1.86524,"data"=>array("drive"=>true,"zip"=>45140,"city"=>"SAINT-JEAN-DE-LA-RUELLE")),
  array("lat"=>47.85124,"lng"=>1.91295,"data"=>array("drive"=>false,"zip"=>45160,"city"=>"OLIVET")),
  array("lat"=>47.52014,"lng"=>-0.6121,"data"=>array("drive"=>true,"zip"=>49240,"city"=>"AVRILLÉ")),
  array("lat"=>47.86821,"lng"=>-3.58399,"data"=>array("drive"=>true,"zip"=>29300,"city"=>"QUIMPERLÉ")),
  array("lat"=>47.29273,"lng"=>-2.20865,"data"=>array("drive"=>true,"zip"=>44570,"city"=>"TRIGNAC")),
  array("lat"=>49.45882,"lng"=>1.04474,"data"=>array("drive"=>false,"zip"=>76380,"city"=>"CANTELEU")),
  array("lat"=>43.56793,"lng"=>1.39254,"data"=>array("drive"=>true,"zip"=>31100,"city"=>"TOULOUSE")),
  array("lat"=>44.90711,"lng"=>-0.48894,"data"=>array("drive"=>false,"zip"=>33560,"city"=>"SAINTE-EULALIE")),
  array("lat"=>47.77714,"lng"=>-3.34227,"data"=>array("drive"=>true,"zip"=>56600,"city"=>"LANESTER")),
  array("lat"=>47.74812,"lng"=>-3.36441,"data"=>array("drive"=>false,"zip"=>56100,"city"=>"LORIENT")),
  array("lat"=>49.26289,"lng"=>6.17279,"data"=>array("drive"=>true,"zip"=>57300,"city"=>"MONDELANGE")),
  array("lat"=>49.24619,"lng"=>6.13644,"data"=>array("drive"=>false,"zip"=>57360,"city"=>"AMNÉVILLE")),
  array("lat"=>49.86683,"lng"=>2.37797,"data"=>array("drive"=>false,"zip"=>80440,"city"=>"GLISY")),
  array("lat"=>49.30455,"lng"=>6.12184,"data"=>array("drive"=>false,"zip"=>57290,"city"=>"FAMECK")),
  array("lat"=>47.81814,"lng"=>6.39622,"data"=>array("drive"=>true,"zip"=>70300,"city"=>"FROIDECONCHE")),
  array("lat"=>46.8602,"lng"=>3.16237,"data"=>array("drive"=>false,"zip"=>58470,"city"=>"MAGNY-COURS")),
  array("lat"=>49.08122,"lng"=>6.1098,"data"=>array("drive"=>true,"zip"=>57685,"city"=>"AUGNY")),
  array("lat"=>47.79406,"lng"=>7.17179,"data"=>array("drive"=>true,"zip"=>68700,"city"=>"CERNAY")),
  array("lat"=>49.09736,"lng"=>2.73929,"data"=>array("drive"=>true,"zip"=>60330,"city"=>"LAGNY-LE-SEC")),
  array("lat"=>45.87687,"lng"=>6.08905,"data"=>array("drive"=>true,"zip"=>74600,"city"=>"SEYNOD")),
  array("lat"=>45.72635,"lng"=>4.83767,"data"=>array("drive"=>true,"zip"=>69007,"city"=>"LYON")),
  array("lat"=>45.79809,"lng"=>4.85099,"data"=>array("drive"=>true,"zip"=>69300,"city"=>"CALUIRE-ET-CUIRE")),
  array("lat"=>45.77038,"lng"=>4.86273,"data"=>array("drive"=>false,"zip"=>69100,"city"=>"VILLEURBANNE")),
  array("lat"=>45.76288,"lng"=>4.913,"data"=>array("drive"=>true,"zip"=>69100,"city"=>"VILLEURBANNE")),
  array("lat"=>45.76203,"lng"=>4.85305,"data"=>array("drive"=>false,"zip"=>69003,"city"=>"LYON")),
  array("lat"=>45.18323,"lng"=>5.71765,"data"=>array("drive"=>false,"zip"=>38000,"city"=>"GRENOBLE")),
  array("lat"=>43.94666,"lng"=>4.80573,"data"=>array("drive"=>false,"zip"=>84000,"city"=>"AVIGNON")),
  array("lat"=>43.92263,"lng"=>4.85849,"data"=>array("drive"=>true,"zip"=>84140,"city"=>"AVIGNON")),
  array("lat"=>43.88799,"lng"=>4.85216,"data"=>array("drive"=>true,"zip"=>13160,"city"=>"CHÂTEAURENARD")),
  array("lat"=>43.97915,"lng"=>4.87833,"data"=>array("drive"=>true,"zip"=>84130,"city"=>"LE PONTET")),
  array("lat"=>45.26952,"lng"=>6.36592,"data"=>array("drive"=>true,"zip"=>73300,"city"=>"SAINT-JEAN-DE-MAURIENNE")),
  array("lat"=>45.76402,"lng"=>4.76885,"data"=>array("drive"=>true,"zip"=>69160,"city"=>"TASSIN-LA-DEMI-LUNE")),
  array("lat"=>45.80191,"lng"=>4.78513,"data"=>array("drive"=>true,"zip"=>69410,"city"=>"CHAMPAGNE-AU-MONT-D'OR")),
  array("lat"=>46.64647,"lng"=>0.36287,"data"=>array("drive"=>true,"zip"=>86360,"city"=>"CHASSENEUIL-DU-POITOU")),
  array("lat"=>46.57244,"lng"=>0.37128,"data"=>array("drive"=>true,"zip"=>86000,"city"=>"POITIERS")),
  array("lat"=>47.48709,"lng"=>6.84365,"data"=>array("drive"=>true,"zip"=>25400,"city"=>"AUDINCOURT")),
  array("lat"=>47.5035,"lng"=>6.81362,"data"=>array("drive"=>true,"zip"=>25200,"city"=>"MONTBÉLIARD")),
  array("lat"=>44.95954,"lng"=>4.884,"data"=>array("drive"=>true,"zip"=>26500,"city"=>"BOURG-LÈS-VALENCE")),
  array("lat"=>44.92958,"lng"=>4.89094,"data"=>array("drive"=>false,"zip"=>26000,"city"=>"VALENCE")),
  array("lat"=>44.93919,"lng"=>4.86454,"data"=>array("drive"=>true,"zip"=>7500,"city"=>"GUILHERAND-GRANGES")),
  array("lat"=>43.29334,"lng"=>5.56373,"data"=>array("drive"=>true,"zip"=>13400,"city"=>"AUBAGNE")),
  array("lat"=>45.72236,"lng"=>4.92014,"data"=>array("drive"=>true,"zip"=>69500,"city"=>"BRON")),
  array("lat"=>45.44064,"lng"=>4.33875,"data"=>array("drive"=>true,"zip"=>42530,"city"=>"SAINT-GENEST-LERPT")),
  array("lat"=>45.73016,"lng"=>4.98583,"data"=>array("drive"=>false,"zip"=>69740,"city"=>"GENAS")),
  array("lat"=>45.95227,"lng"=>6.62943,"data"=>array("drive"=>true,"zip"=>74700,"city"=>"SALLANCHES")),
  array("lat"=>43.82033,"lng"=>5.79471,"data"=>array("drive"=>true,"zip"=>4100,"city"=>"MANOSQUE")),
  array("lat"=>44.07715,"lng"=>6.18663,"data"=>array("drive"=>true,"zip"=>4000,"city"=>"DIGNE-LES-BAINS")),
  array("lat"=>45.78931,"lng"=>4.77706,"data"=>array("drive"=>false,"zip"=>69130,"city"=>"ÉCULLY")),
  array("lat"=>45.89514,"lng"=>4.82127,"data"=>array("drive"=>true,"zip"=>69730,"city"=>"GENAY")),
  array("lat"=>43.68185,"lng"=>5.50136,"data"=>array("drive"=>true,"zip"=>84120,"city"=>"PERTUIS")),
  array("lat"=>50.94238,"lng"=>1.8074,"data"=>array("drive"=>true,"zip"=>62231,"city"=>"COQUELLES")),
  array("lat"=>47.2763,"lng"=>5.99205,"data"=>array("drive"=>true,"zip"=>25480,"city"=>"ÉCOLE-VALENTIN")),
  array("lat"=>48.29733,"lng"=>4.13428,"data"=>array("drive"=>true,"zip"=>10410,"city"=>"SAINT-PARRES-AUX-TERTRES")),
  array("lat"=>48.9169,"lng"=>2.41718,"data"=>array("drive"=>true,"zip"=>93000,"city"=>"BOBIGNY")),
  array("lat"=>48.77964,"lng"=>2.45692,"data"=>array("drive"=>false,"zip"=>94000,"city"=>"CRÉTEIL")),
  array("lat"=>48.86478,"lng"=>2.39798,"data"=>array("drive"=>false,"zip"=>75020,"city"=>"PARIS")),
  array("lat"=>48.9288,"lng"=>2.55562,"data"=>array("drive"=>true,"zip"=>93190,"city"=>"LIVRY-GARGAN")),
  array("lat"=>48.92591,"lng"=>2.29182,"data"=>array("drive"=>false,"zip"=>92230,"city"=>"GENNEVILLIERS")),
  array("lat"=>48.76736,"lng"=>2.48538,"data"=>array("drive"=>true,"zip"=>94380,"city"=>"BONNEUIL-SUR-MARNE")),
  array("lat"=>48.85402,"lng"=>2.36989,"data"=>array("drive"=>false,"zip"=>75011,"city"=>"PARIS")),
  array("lat"=>48.8672,"lng"=>2.38268,"data"=>array("drive"=>false,"zip"=>75011,"city"=>"PARIS")),
  array("lat"=>48.88932,"lng"=>2.3749,"data"=>array("drive"=>false,"zip"=>75019,"city"=>"PARIS")),
  array("lat"=>48.76281,"lng"=>2.36822,"data"=>array("drive"=>true,"zip"=>94550,"city"=>"CHEVILLY-LARUE")),
  array("lat"=>48.95419,"lng"=>2.56219,"data"=>array("drive"=>true,"zip"=>93420,"city"=>"VILLEPINTE")),
  array("lat"=>48.70937,"lng"=>2.37138,"data"=>array("drive"=>true,"zip"=>91200,"city"=>"ATHIS-MONS")),
  array("lat"=>48.52304,"lng"=>2.65319,"data"=>array("drive"=>true,"zip"=>77190,"city"=>"DAMMARIE-LES-LYS")),
  array("lat"=>48.27736,"lng"=>2.68479,"data"=>array("drive"=>true,"zip"=>77140,"city"=>"SAINT-PIERRE-LÈS-NEMOURS")),
  array("lat"=>49.04233,"lng"=>2.33891,"data"=>array("drive"=>true,"zip"=>95570,"city"=>"MOISSELLES")),
  array("lat"=>48.58795,"lng"=>2.30319,"data"=>array("drive"=>true,"zip"=>91220,"city"=>"BRÉTIGNY-SUR-ORGE")),
  array("lat"=>49.0424,"lng"=>2.07204,"data"=>array("drive"=>true,"zip"=>95000,"city"=>"CERGY")),
  array("lat"=>49.0084,"lng"=>2.35116,"data"=>array("drive"=>true,"zip"=>95350,"city"=>"SAINT-BRICE-SOUS-FORÊT")),
  array("lat"=>49.05496,"lng"=>2.02457,"data"=>array("drive"=>true,"zip"=>95650,"city"=>"PUISEUX-PONTOISE")),
  array("lat"=>48.92126,"lng"=>2.36359,"data"=>array("drive"=>true,"zip"=>93210,"city"=>"SAINT-DENIS")),
  array("lat"=>48.78543,"lng"=>2.43605,"data"=>array("drive"=>true,"zip"=>94000,"city"=>"CRÉTEIL")),
  array("lat"=>48.69284,"lng"=>2.33834,"data"=>array("drive"=>true,"zip"=>91420,"city"=>"MORANGIS")),
  array("lat"=>43.60605,"lng"=>3.14947,"data"=>array("drive"=>true,"zip"=>34600,"city"=>"BÉDARIEUX")),
  array("lat"=>48.27327,"lng"=>4.08753,"data"=>array("drive"=>true,"zip"=>10800,"city"=>"SAINT-JULIEN-LES-VILLAS")),
  array("lat"=>46.07347,"lng"=>6.40865,"data"=>array("drive"=>true,"zip"=>74130,"city"=>"BONNEVILLE")),
  array("lat"=>46.06689,"lng"=>6.55505,"data"=>array("drive"=>true,"zip"=>74950,"city"=>"SCIONZIER")),
  array("lat"=>45.92332,"lng"=>6.87133,"data"=>array("drive"=>false,"zip"=>74400,"city"=>"CHAMONIX-MONT-BLANC")),
  array("lat"=>45.59364,"lng"=>4.08286,"data"=>array("drive"=>true,"zip"=>42600,"city"=>"MONTBRISON")),
  array("lat"=>44.90373,"lng"=>6.62808,"data"=>array("drive"=>true,"zip"=>5100,"city"=>"BRIANÇON")),
  array("lat"=>45.96881,"lng"=>5.35371,"data"=>array("drive"=>true,"zip"=>1500,"city"=>"AMBÉRIEU-EN-BUGEY")),
  array("lat"=>45.56817,"lng"=>5.42898,"data"=>array("drive"=>true,"zip"=>38110,"city"=>"SAINT-JEAN-DE-SOUDAIN")),
  array("lat"=>43.88721,"lng"=>5.3673,"data"=>array("drive"=>false,"zip"=>84400,"city"=>"GARGAS")),
  array("lat"=>50.27437,"lng"=>3.96818,"data"=>array("drive"=>false,"zip"=>59600,"city"=>"MAUBEUGE")),
  array("lat"=>51.0326,"lng"=>2.37063,"data"=>array("drive"=>false,"zip"=>59140,"city"=>"DUNKERQUE")),
  array("lat"=>50.34192,"lng"=>3.09846,"data"=>array("drive"=>true,"zip"=>59450,"city"=>"SIN-LE-NOBLE")),
  array("lat"=>50.50912,"lng"=>1.6311,"data"=>array("drive"=>true,"zip"=>62780,"city"=>"CUCQ")),
  array("lat"=>50.39751,"lng"=>3.04595,"data"=>array("drive"=>false,"zip"=>59128,"city"=>"FLERS-EN-ESCREBIEUX")),
  array("lat"=>49.45191,"lng"=>2.09792,"data"=>array("drive"=>true,"zip"=>60000,"city"=>"BEAUVAIS")),
  array("lat"=>48.12855,"lng"=>7.36371,"data"=>array("drive"=>true,"zip"=>68125,"city"=>"HOUSSEN")),
  array("lat"=>45.29542,"lng"=>5.62915,"data"=>array("drive"=>true,"zip"=>38340,"city"=>"VOREPPE")),
  array("lat"=>45.05307,"lng"=>4.83659,"data"=>array("drive"=>true,"zip"=>7300,"city"=>"TOURNON-SUR-RHÔNE")),
  array("lat"=>45.25498,"lng"=>4.6888,"data"=>array("drive"=>true,"zip"=>7430,"city"=>"DAVÉZIEUX")),
  array("lat"=>45.34073,"lng"=>4.80551,"data"=>array("drive"=>true,"zip"=>38150,"city"=>"SALAISE-SUR-SANNE")),
  array("lat"=>43.2941,"lng"=>5.48277,"data"=>array("drive"=>false,"zip"=>13011,"city"=>"MARSEILLE")),
  array("lat"=>45.89024,"lng"=>4.44463,"data"=>array("drive"=>true,"zip"=>69170,"city"=>"TARARE")),
  array("lat"=>44.61649,"lng"=>4.40454,"data"=>array("drive"=>true,"zip"=>7200,"city"=>"AUBENAS")),
  array("lat"=>45.85796,"lng"=>5.94438,"data"=>array("drive"=>true,"zip"=>74150,"city"=>"RUMILLY")),
  array("lat"=>45.68023,"lng"=>4.79356,"data"=>array("drive"=>false,"zip"=>69230,"city"=>"SAINT-GENIS-LAVAL")),
  array("lat"=>45.66483,"lng"=>6.39016,"data"=>array("drive"=>true,"zip"=>73200,"city"=>"ALBERTVILLE")),
  array("lat"=>45.7125,"lng"=>4.87961,"data"=>array("drive"=>true,"zip"=>69200,"city"=>"VÉNISSIEUX")),
  array("lat"=>45.93325,"lng"=>6.08233,"data"=>array("drive"=>true,"zip"=>74330,"city"=>"ÉPAGNY")),
  array("lat"=>48.85474,"lng"=>2.78266,"data"=>array("drive"=>false,"zip"=>77700,"city"=>"SERRIS")),
  array("lat"=>48.85474,"lng"=>2.78266,"data"=>array("drive"=>true,"zip"=>77700,"city"=>"SERRIS")),
  array("lat"=>49.08927,"lng"=>2.556,"data"=>array("drive"=>true,"zip"=>95470,"city"=>"SAINT-WITZ")),
  array("lat"=>48.79919,"lng"=>2.03486,"data"=>array("drive"=>true,"zip"=>78390,"city"=>"BOIS-D'ARCY")),
  array("lat"=>48.50074,"lng"=>2.5831,"data"=>array("drive"=>false,"zip"=>77190,"city"=>"VILLIERS-EN-BIÈRE")),
  array("lat"=>48.80545,"lng"=>2.53463,"data"=>array("drive"=>true,"zip"=>94430,"city"=>"CHENNEVIÈRES-SUR-MARNE")),
  array("lat"=>48.71569,"lng"=>2.29953,"data"=>array("drive"=>true,"zip"=>91380,"city"=>"CHILLY-MAZARIN")),
  array("lat"=>48.7039,"lng"=>2.25326,"data"=>array("drive"=>true,"zip"=>91140,"city"=>"VILLEBON-SUR-YVETTE")),
  array("lat"=>48.81966,"lng"=>2.39613,"data"=>array("drive"=>false,"zip"=>94200,"city"=>"IVRY-SUR-SEINE")),
  array("lat"=>48.79222,"lng"=>2.32033,"data"=>array("drive"=>true,"zip"=>94230,"city"=>"CACHAN")),
  array("lat"=>48.93052,"lng"=>2.48295,"data"=>array("drive"=>false,"zip"=>93600,"city"=>"AULNAY-SOUS-BOIS")),
  array("lat"=>48.8308,"lng"=>2.35655,"data"=>array("drive"=>false,"zip"=>75013,"city"=>"PARIS")),
  array("lat"=>48.92513,"lng"=>1.99394,"data"=>array("drive"=>true,"zip"=>78630,"city"=>"ORGEVAL")),
  array("lat"=>48.72346,"lng"=>2.27654,"data"=>array("drive"=>false,"zip"=>91300,"city"=>"MASSY")),
  array("lat"=>48.84189,"lng"=>2.54323,"data"=>array("drive"=>false,"zip"=>93160,"city"=>"NOISY-LE-GRAND")),
  array("lat"=>48.84189,"lng"=>2.54323,"data"=>array("drive"=>false,"zip"=>93160,"city"=>"NOISY-LE-GRAND")),
  array("lat"=>48.62366,"lng"=>2.37018,"data"=>array("drive"=>true,"zip"=>91700,"city"=>"FLEURY-MÉROGIS")),
  array("lat"=>48.94805,"lng"=>2.20626,"data"=>array("drive"=>true,"zip"=>95100,"city"=>"ARGENTEUIL")),
  array("lat"=>48.83424,"lng"=>2.64132,"data"=>array("drive"=>true,"zip"=>77185,"city"=>"LOGNES")),
  array("lat"=>48.94637,"lng"=>2.62477,"data"=>array("drive"=>true,"zip"=>77270,"city"=>"VILLEPARISIS")),
  array("lat"=>48.78358,"lng"=>2.04027,"data"=>array("drive"=>false,"zip"=>78180,"city"=>"MONTIGNY-LE-BRETONNEUX")),
  array("lat"=>48.98972,"lng"=>1.74858,"data"=>array("drive"=>true,"zip"=>78520,"city"=>"LIMAY")),
  array("lat"=>48.89073,"lng"=>2.23641,"data"=>array("drive"=>false,"zip"=>92800,"city"=>"PUTEAUX")),
  array("lat"=>48.94712,"lng"=>2.3754,"data"=>array("drive"=>true,"zip"=>93240,"city"=>"STAINS")),
  array("lat"=>48.84213,"lng"=>2.65642,"data"=>array("drive"=>false,"zip"=>77200,"city"=>"TORCY")),
  array("lat"=>48.92845,"lng"=>2.14389,"data"=>array("drive"=>false,"zip"=>78360,"city"=>"MONTESSON")),
  array("lat"=>48.70206,"lng"=>2.10638,"data"=>array("drive"=>true,"zip"=>91190,"city"=>"GIF-SUR-YVETTE")),
  array("lat"=>48.66154,"lng"=>2.375,"data"=>array("drive"=>true,"zip"=>91170,"city"=>"VIRY-CHÂTILLON")),
  array("lat"=>48.90593,"lng"=>2.44569,"data"=>array("drive"=>false,"zip"=>93000,"city"=>"BOBIGNY")),
  array("lat"=>48.90463,"lng"=>2.54935,"data"=>array("drive"=>true,"zip"=>93390,"city"=>"CLICHY-SOUS-BOIS")),
  array("lat"=>48.99053,"lng"=>2.43252,"data"=>array("drive"=>true,"zip"=>95500,"city"=>"GONESSE")),
  array("lat"=>49.01511,"lng"=>2.21916,"data"=>array("drive"=>false,"zip"=>95150,"city"=>"TAVERNY")),
  array("lat"=>49.0372,"lng"=>2.07961,"data"=>array("drive"=>false,"zip"=>95000,"city"=>"CERGY")),
  array("lat"=>49.0372,"lng"=>2.07961,"data"=>array("drive"=>false,"zip"=>95000,"city"=>"CERGY")),
  array("lat"=>48.56828,"lng"=>2.2316,"data"=>array("drive"=>true,"zip"=>91630,"city"=>"AVRAINVILLE")),
  array("lat"=>49.03583,"lng"=>2.12116,"data"=>array("drive"=>true,"zip"=>95310,"city"=>"SAINT-OUEN-L'AUMÔNE")),
  array("lat"=>48.55705,"lng"=>2.63757,"data"=>array("drive"=>true,"zip"=>77000,"city"=>"MELUN")),
  array("lat"=>48.42374,"lng"=>2.73924,"data"=>array("drive"=>true,"zip"=>77210,"city"=>"AVON")),
  array("lat"=>48.68305,"lng"=>2.2056,"data"=>array("drive"=>true,"zip"=>91140,"city"=>"VILLEJUST")),
  array("lat"=>48.94292,"lng"=>2.02919,"data"=>array("drive"=>true,"zip"=>78955,"city"=>"CARRIÈRES-SOUS-POISSY")),
  array("lat"=>48.98858,"lng"=>2.07337,"data"=>array("drive"=>true,"zip"=>78700,"city"=>"CONFLANS-SAINTE-HONORINE")),
  array("lat"=>48.96757,"lng"=>1.86702,"data"=>array("drive"=>true,"zip"=>78410,"city"=>"FLINS-SUR-SEINE")),
  array("lat"=>43.46623,"lng"=>5.46506,"data"=>array("drive"=>false,"zip"=>13120,"city"=>"GARDANNE")),
  array("lat"=>43.42801,"lng"=>6.73637,"data"=>array("drive"=>true,"zip"=>83600,"city"=>"FRÉJUS")),
  array("lat"=>45.85658,"lng"=>4.70258,"data"=>array("drive"=>true,"zip"=>69380,"city"=>"CIVRIEUX-D'AZERGUES")),
  array("lat"=>44.75962,"lng"=>4.83657,"data"=>array("drive"=>true,"zip"=>26270,"city"=>"LORIOL-SUR-DRÔME")),
  array("lat"=>44.28927,"lng"=>4.75142,"data"=>array("drive"=>true,"zip"=>84500,"city"=>"BOLLÈNE")),
  array("lat"=>44.32202,"lng"=>4.74402,"data"=>array("drive"=>false,"zip"=>84500,"city"=>"BOLLÈNE")),
  array("lat"=>44.36858,"lng"=>4.69324,"data"=>array("drive"=>true,"zip"=>26700,"city"=>"PIERRELATTE")),
  array("lat"=>45.7345,"lng"=>4.77316,"data"=>array("drive"=>false,"zip"=>69340,"city"=>"FRANCHEVILLE")),
  array("lat"=>43.72826,"lng"=>7.18795,"data"=>array("drive"=>false,"zip"=>6200,"city"=>"NICE")),
  array("lat"=>45.81739,"lng"=>4.88928,"data"=>array("drive"=>true,"zip"=>69140,"city"=>"RILLIEUX-LA-PAPE")),
  array("lat"=>43.59989,"lng"=>7.08675,"data"=>array("drive"=>true,"zip"=>6600,"city"=>"ANTIBES")),
  array("lat"=>43.98247,"lng"=>4.86059,"data"=>array("drive"=>true,"zip"=>84130,"city"=>"LE PONTET")),
  array("lat"=>43.60348,"lng"=>7.09004,"data"=>array("drive"=>false,"zip"=>6600,"city"=>"ANTIBES")),
  array("lat"=>45.58473,"lng"=>4.7519,"data"=>array("drive"=>false,"zip"=>69700,"city"=>"GIVORS")),
  array("lat"=>43.9396,"lng"=>4.83777,"data"=>array("drive"=>true,"zip"=>84000,"city"=>"AVIGNON")),
  array("lat"=>50.45639,"lng"=>3.59168,"data"=>array("drive"=>true,"zip"=>59163,"city"=>"CONDÉ-SUR-L'ESCAUT")),
  array("lat"=>50.64157,"lng"=>3.07165,"data"=>array("drive"=>true,"zip"=>59000,"city"=>"LILLE")),
  array("lat"=>49.06726,"lng"=>6.14455,"data"=>array("drive"=>true,"zip"=>57155,"city"=>"MARLY")),
  array("lat"=>49.23006,"lng"=>2.89699,"data"=>array("drive"=>true,"zip"=>60800,"city"=>"CRÉPY-EN-VALOIS")),
  array("lat"=>50.47434,"lng"=>2.67806,"data"=>array("drive"=>true,"zip"=>62290,"city"=>"NOEUX-LES-MINES")),
  array("lat"=>47.62682,"lng"=>6.17059,"data"=>array("drive"=>true,"zip"=>70000,"city"=>"VESOUL")),
  array("lat"=>47.43535,"lng"=>5.60162,"data"=>array("drive"=>true,"zip"=>70100,"city"=>"GRAY")),
  array("lat"=>49.38276,"lng"=>2.40185,"data"=>array("drive"=>true,"zip"=>60600,"city"=>"CLERMONT")),
  array("lat"=>48.77563,"lng"=>5.16322,"data"=>array("drive"=>true,"zip"=>55000,"city"=>"BAR-LE-DUC")),
  array("lat"=>48.72931,"lng"=>4.58894,"data"=>array("drive"=>true,"zip"=>51300,"city"=>"VITRY-LE-FRANÇOIS")),
  array("lat"=>49.52009,"lng"=>4.37387,"data"=>array("drive"=>true,"zip"=>8300,"city"=>"RETHEL")),
  array("lat"=>46.66901,"lng"=>5.54928,"data"=>array("drive"=>true,"zip"=>39000,"city"=>"LONS-LE-SAUNIER")),
  array("lat"=>48.62275,"lng"=>2.56305,"data"=>array("drive"=>true,"zip"=>77550,"city"=>"MOISSY-CRAMAYEL")),
  array("lat"=>48.55438,"lng"=>2.67123,"data"=>array("drive"=>true,"zip"=>77950,"city"=>"RUBELLES")),
  array("lat"=>48.94153,"lng"=>2.87982,"data"=>array("drive"=>true,"zip"=>77100,"city"=>"NANTEUIL-LÈS-MEAUX")),
  array("lat"=>48.58638,"lng"=>2.59723,"data"=>array("drive"=>true,"zip"=>77240,"city"=>"CESSON")),
  array("lat"=>48.4336,"lng"=>2.17059,"data"=>array("drive"=>true,"zip"=>91150,"city"=>"ÉTAMPES")),
  array("lat"=>45.64835,"lng"=>0.15988,"data"=>array("drive"=>false,"zip"=>16000,"city"=>"ANGOULÊME")),
  array("lat"=>45.63322,"lng"=>0.21283,"data"=>array("drive"=>true,"zip"=>16800,"city"=>"SOYAUX")),
  array("lat"=>43.55459,"lng"=>1.46735,"data"=>array("drive"=>true,"zip"=>31400,"city"=>"TOULOUSE")),
  array("lat"=>47.36544,"lng"=>0.67565,"data"=>array("drive"=>true,"zip"=>37200,"city"=>"TOURS")),
  array("lat"=>47.67021,"lng"=>-2.06799,"data"=>array("drive"=>true,"zip"=>35600,"city"=>"REDON")),
  array("lat"=>45.82105,"lng"=>4.99077,"data"=>array("drive"=>true,"zip"=>1700,"city"=>"BEYNOST")),
  array("lat"=>43.51045,"lng"=>6.47858,"data"=>array("drive"=>true,"zip"=>83720,"city"=>"TRANS-EN-PROVENCE")),
  array("lat"=>46.1062,"lng"=>4.75145,"data"=>array("drive"=>true,"zip"=>69220,"city"=>"BELLEVILLE")),
  array("lat"=>45.03806,"lng"=>5.05659,"data"=>array("drive"=>false,"zip"=>26300,"city"=>"BOURG-DE-PÉAGE")),
  array("lat"=>49.08896,"lng"=>0.60361,"data"=>array("drive"=>true,"zip"=>27300,"city"=>"BERNAY")),
  array("lat"=>48.21658,"lng"=>-4.05027,"data"=>array("drive"=>true,"zip"=>29150,"city"=>"CHÂTEAULIN")),
  array("lat"=>48.11382,"lng"=>-1.6201,"data"=>array("drive"=>true,"zip"=>35510,"city"=>"CESSON-SÉVIGNÉ")),
  array("lat"=>48.13208,"lng"=>-1.68996,"data"=>array("drive"=>true,"zip"=>35000,"city"=>"RENNES")),
  array("lat"=>48.08229,"lng"=>-1.67993,"data"=>array("drive"=>false,"zip"=>35200,"city"=>"RENNES")),
  array("lat"=>48.10458,"lng"=>-1.68026,"data"=>array("drive"=>false,"zip"=>35000,"city"=>"RENNES")),
  array("lat"=>45.13021,"lng"=>-0.64566,"data"=>array("drive"=>true,"zip"=>33390,"city"=>"SAINT-MARTIN-LACAUSSADE")),
  array("lat"=>44.99593,"lng"=>-0.44525,"data"=>array("drive"=>true,"zip"=>33240,"city"=>"SAINT-ANDRÉ-DE-CUBZAC")),
  array("lat"=>43.53382,"lng"=>1.40109,"data"=>array("drive"=>true,"zip"=>31120,"city"=>"PORTET-SUR-GARONNE")),
  array("lat"=>43.55006,"lng"=>1.41845,"data"=>array("drive"=>true,"zip"=>31100,"city"=>"TOULOUSE")),
  array("lat"=>43.48271,"lng"=>-1.50295,"data"=>array("drive"=>true,"zip"=>64100,"city"=>"BAYONNE")),
  array("lat"=>45.78808,"lng"=>3.1051,"data"=>array("drive"=>false,"zip"=>63100,"city"=>"CLERMONT-FERRAND")),
  array("lat"=>43.5858,"lng"=>3.88881,"data"=>array("drive"=>true,"zip"=>34070,"city"=>"MONTPELLIER")),
  array("lat"=>44.87018,"lng"=>-0.56566,"data"=>array("drive"=>true,"zip"=>33300,"city"=>"BORDEAUX")),
  array("lat"=>43.60268,"lng"=>3.91583,"data"=>array("drive"=>true,"zip"=>34000,"city"=>"MONTPELLIER")),
  array("lat"=>45.83002,"lng"=>-1.11934,"data"=>array("drive"=>true,"zip"=>17320,"city"=>"MARENNES")),
  array("lat"=>45.88935,"lng"=>3.07427,"data"=>array("drive"=>true,"zip"=>63200,"city"=>"MOZAC")),
  array("lat"=>43.65984,"lng"=>3.90405,"data"=>array("drive"=>true,"zip"=>34830,"city"=>"JACOU")),
  array("lat"=>45.78122,"lng"=>1.30518,"data"=>array("drive"=>true,"zip"=>87110,"city"=>"LE VIGEN")),
  array("lat"=>43.42311,"lng"=>6.76609,"data"=>array("drive"=>false,"zip"=>83700,"city"=>"SAINT-RAPHAËL")),
  array("lat"=>44.13614,"lng"=>4.79915,"data"=>array("drive"=>true,"zip"=>84100,"city"=>"ORANGE")),
  array("lat"=>49.34703,"lng"=>0.0968,"data"=>array("drive"=>true,"zip"=>14800,"city"=>"TOUQUES")),
  array("lat"=>49.28528,"lng"=>-0.10253,"data"=>array("drive"=>false,"zip"=>14160,"city"=>"DIVES-SUR-MER")),
  array("lat"=>46.78408,"lng"=>4.85282,"data"=>array("drive"=>false,"zip"=>71100,"city"=>"CHALON-SUR-SAÔNE")),
  array("lat"=>46.78817,"lng"=>4.8667,"data"=>array("drive"=>false,"zip"=>71100,"city"=>"CHALON-SUR-SAÔNE")),
  array("lat"=>48.60435,"lng"=>7.70535,"data"=>array("drive"=>true,"zip"=>67205,"city"=>"OBERHAUSBERGEN")),
  array("lat"=>49.16521,"lng"=>5.8423,"data"=>array("drive"=>true,"zip"=>54800,"city"=>"CONFLANS-EN-JARNISY")),
  array("lat"=>50.63629,"lng"=>2.41159,"data"=>array("drive"=>true,"zip"=>62120,"city"=>"AIRE-SUR-LA-LYS")),
  array("lat"=>50.40329,"lng"=>1.59424,"data"=>array("drive"=>true,"zip"=>62600,"city"=>"BERCK")),
  array("lat"=>48.04325,"lng"=>7.16075,"data"=>array("drive"=>true,"zip"=>68140,"city"=>"MUNSTER")),
  array("lat"=>47.58617,"lng"=>7.56219,"data"=>array("drive"=>false,"zip"=>68300,"city"=>"SAINT-LOUIS")),
  array("lat"=>50.9529,"lng"=>1.89091,"data"=>array("drive"=>false,"zip"=>62100,"city"=>"CALAIS")),
  array("lat"=>48.90128,"lng"=>6.06408,"data"=>array("drive"=>true,"zip"=>54700,"city"=>"PONT-À-MOUSSON")),
  array("lat"=>48.73863,"lng"=>7.07884,"data"=>array("drive"=>true,"zip"=>57400,"city"=>"SARREBOURG")),
  array("lat"=>43.09533,"lng"=>-0.04628,"data"=>array("drive"=>false,"zip"=>65100,"city"=>"LOURDES")),
  array("lat"=>43.11384,"lng"=>0.75978,"data"=>array("drive"=>true,"zip"=>31800,"city"=>"ESTANCARBON")),
  array("lat"=>42.94891,"lng"=>1.62436,"data"=>array("drive"=>true,"zip"=>9000,"city"=>"FOIX")),
  array("lat"=>45.69265,"lng"=>0.18124,"data"=>array("drive"=>true,"zip"=>16430,"city"=>"CHAMPNIERS")),
  array("lat"=>43.27876,"lng"=>-0.36056,"data"=>array("drive"=>true,"zip"=>64110,"city"=>"MAZÈRES-LEZONS")),
  array("lat"=>46.11194,"lng"=>-1.10266,"data"=>array("drive"=>true,"zip"=>17690,"city"=>"ANGOULINS")),
  array("lat"=>48.01804,"lng"=>-4.08614,"data"=>array("drive"=>true,"zip"=>29000,"city"=>"QUIMPER")),
  array("lat"=>47.97847,"lng"=>-4.09504,"data"=>array("drive"=>true,"zip"=>29000,"city"=>"QUIMPER")),
  array("lat"=>46.28785,"lng"=>4.81041,"data"=>array("drive"=>true,"zip"=>71000,"city"=>"MÂCON")),
  array("lat"=>47.902,"lng"=>7.22278,"data"=>array("drive"=>true,"zip"=>68500,"city"=>"GUEBWILLER")),
  array("lat"=>50.73989,"lng"=>2.2597,"data"=>array("drive"=>true,"zip"=>62219,"city"=>"LONGUENESSE")),
  array("lat"=>49.03679,"lng"=>3.38273,"data"=>array("drive"=>true,"zip"=>2400,"city"=>"CHÂTEAU-THIERRY")),
  array("lat"=>47.67292,"lng"=>6.51029,"data"=>array("drive"=>true,"zip"=>70200,"city"=>"LURE")),
  array("lat"=>49.10886,"lng"=>6.71819,"data"=>array("drive"=>true,"zip"=>57500,"city"=>"SAINT-AVOLD")),
  array("lat"=>50.00915,"lng"=>2.66887,"data"=>array("drive"=>true,"zip"=>80300,"city"=>"ALBERT")),
  array("lat"=>49.14569,"lng"=>5.40792,"data"=>array("drive"=>true,"zip"=>55100,"city"=>"VERDUN")),
  array("lat"=>49.94206,"lng"=>2.93128,"data"=>array("drive"=>true,"zip"=>80200,"city"=>"PÉRONNE")),
  array("lat"=>50.06056,"lng"=>1.40664,"data"=>array("drive"=>true,"zip"=>80350,"city"=>"MERS-LES-BAINS")),
  array("lat"=>48.50949,"lng"=>3.71543,"data"=>array("drive"=>true,"zip"=>10100,"city"=>"ROMILLY-SUR-SEINE")),
  array("lat"=>49.22102,"lng"=>2.13827,"data"=>array("drive"=>true,"zip"=>60110,"city"=>"MÉRU")),
  array("lat"=>50.72353,"lng"=>2.74064,"data"=>array("drive"=>false,"zip"=>59270,"city"=>"BAILLEUL")),
  array("lat"=>49.18927,"lng"=>6.69494,"data"=>array("drive"=>true,"zip"=>57150,"city"=>"CREUTZWALD")),
  array("lat"=>49.51819,"lng"=>5.75443,"data"=>array("drive"=>true,"zip"=>54400,"city"=>"LONGWY")),
  array("lat"=>48.67032,"lng"=>5.89,"data"=>array("drive"=>true,"zip"=>54200,"city"=>"TOUL")),
  array("lat"=>50.02788,"lng"=>4.03121,"data"=>array("drive"=>true,"zip"=>59610,"city"=>"FOURMIES")),
  array("lat"=>49.91076,"lng"=>4.09158,"data"=>array("drive"=>true,"zip"=>2500,"city"=>"HIRSON")),
  array("lat"=>47.60508,"lng"=>7.54393,"data"=>array("drive"=>true,"zip"=>68300,"city"=>"SAINT-LOUIS")),
  array("lat"=>49.64377,"lng"=>3.261,"data"=>array("drive"=>true,"zip"=>2300,"city"=>"VIRY-NOUREUIL")),
  array("lat"=>48.60326,"lng"=>6.36337,"data"=>array("drive"=>false,"zip"=>54110,"city"=>"DOMBASLE-SUR-MEURTHE")),
  array("lat"=>47.21903,"lng"=>5.94567,"data"=>array("drive"=>true,"zip"=>25000,"city"=>"BESANÇON")),
  array("lat"=>45.53464,"lng"=>4.87262,"data"=>array("drive"=>true,"zip"=>38200,"city"=>"VIENNE")),
  array("lat"=>43.22156,"lng"=>0.06148,"data"=>array("drive"=>true,"zip"=>65000,"city"=>"TARBES")),
  array("lat"=>46.16753,"lng"=>1.88593,"data"=>array("drive"=>true,"zip"=>23000,"city"=>"GUÉRET")),
  array("lat"=>44.51672,"lng"=>3.48492,"data"=>array("drive"=>true,"zip"=>48000,"city"=>"MENDE")),
  array("lat"=>45.69062,"lng"=>-0.32145,"data"=>array("drive"=>true,"zip"=>16100,"city"=>"COGNAC")),
  array("lat"=>44.36021,"lng"=>2.01127,"data"=>array("drive"=>true,"zip"=>12200,"city"=>"VILLEFRANCHE-DE-ROUERGUE")),
  array("lat"=>46.14849,"lng"=>-1.15316,"data"=>array("drive"=>false,"zip"=>17000,"city"=>"LA ROCHELLE")),
  array("lat"=>45.12917,"lng"=>1.3247,"data"=>array("drive"=>true,"zip"=>24120,"city"=>"TERRASSON-LAVILLEDIEU")),
  array("lat"=>43.48789,"lng"=>-0.77993,"data"=>array("drive"=>true,"zip"=>64300,"city"=>"ORTHEZ")),
  array("lat"=>43.72332,"lng"=>-1.05062,"data"=>array("drive"=>true,"zip"=>40990,"city"=>"SAINT-PAUL-LÈS-DAX")),
  array("lat"=>43.30052,"lng"=>1.95548,"data"=>array("drive"=>true,"zip"=>11400,"city"=>"CASTELNAUDARY")),
  array("lat"=>43.49863,"lng"=>2.38637,"data"=>array("drive"=>true,"zip"=>81200,"city"=>"MAZAMET")),
  array("lat"=>45.25378,"lng"=>1.76103,"data"=>array("drive"=>true,"zip"=>19000,"city"=>"TULLE")),
  array("lat"=>44.84486,"lng"=>0.17881,"data"=>array("drive"=>true,"zip"=>33220,"city"=>"PORT-SAINTE-FOY-ET-PONCHAPT")),
  array("lat"=>42.6998,"lng"=>2.93526,"data"=>array("drive"=>true,"zip"=>66000,"city"=>"PERPIGNAN")),
  array("lat"=>45.551,"lng"=>3.26706,"data"=>array("drive"=>true,"zip"=>63500,"city"=>"ISSOIRE")),
  array("lat"=>42.67271,"lng"=>2.88987,"data"=>array("drive"=>true,"zip"=>66100,"city"=>"PERPIGNAN")),
  array("lat"=>43.18177,"lng"=>-0.61915,"data"=>array("drive"=>true,"zip"=>64400,"city"=>"OLORON-SAINTE-MARIE")),
  array("lat"=>43.66591,"lng"=>4.63669,"data"=>array("drive"=>true,"zip"=>13200,"city"=>"ARLES")),
  array("lat"=>43.67528,"lng"=>4.62777,"data"=>array("drive"=>false,"zip"=>13200,"city"=>"ARLES")),
  array("lat"=>45.72011,"lng"=>4.22684,"data"=>array("drive"=>true,"zip"=>42110,"city"=>"FEURS")),
  array("lat"=>43.65284,"lng"=>6.94545,"data"=>array("drive"=>true,"zip"=>6130,"city"=>"GRASSE")),
  array("lat"=>47.60577,"lng"=>1.32785,"data"=>array("drive"=>true,"zip"=>41000,"city"=>"BLOIS")),
  array("lat"=>48.05388,"lng"=>-0.74011,"data"=>array("drive"=>true,"zip"=>53000,"city"=>"LAVAL")),
  array("lat"=>48.07771,"lng"=>-0.79915,"data"=>array("drive"=>true,"zip"=>53000,"city"=>"LAVAL")),
  array("lat"=>43.34304,"lng"=>3.21635,"data"=>array("drive"=>false,"zip"=>34500,"city"=>"BÉZIERS")),
  array("lat"=>43.34875,"lng"=>3.25045,"data"=>array("drive"=>true,"zip"=>34500,"city"=>"BÉZIERS")),
  array("lat"=>44.79292,"lng"=>-0.53001,"data"=>array("drive"=>true,"zip"=>33130,"city"=>"BÈGLES")),
  array("lat"=>46.33804,"lng"=>2.56608,"data"=>array("drive"=>true,"zip"=>3410,"city"=>"DOMÉRAT")),
  array("lat"=>49.43161,"lng"=>2.08403,"data"=>array("drive"=>false,"zip"=>60000,"city"=>"BEAUVAIS")),
  array("lat"=>49.40826,"lng"=>2.11265,"data"=>array("drive"=>true,"zip"=>60000,"city"=>"BEAUVAIS")),
  array("lat"=>47.8072,"lng"=>7.31359,"data"=>array("drive"=>true,"zip"=>68270,"city"=>"WITTENHEIM")),
  array("lat"=>49.34882,"lng"=>6.17826,"data"=>array("drive"=>true,"zip"=>57970,"city"=>"YUTZ")),
  array("lat"=>48.57857,"lng"=>6.51688,"data"=>array("drive"=>true,"zip"=>54300,"city"=>"LUNÉVILLE")),
  array("lat"=>46.0358,"lng"=>4.07118,"data"=>array("drive"=>false,"zip"=>42300,"city"=>"ROANNE")),
  array("lat"=>47.0625,"lng"=>2.36843,"data"=>array("drive"=>false,"zip"=>18000,"city"=>"BOURGES")),
  array("lat"=>47.79931,"lng"=>-3.25809,"data"=>array("drive"=>true,"zip"=>56700,"city"=>"HENNEBONT")),
  array("lat"=>48.10432,"lng"=>-1.71225,"data"=>array("drive"=>true,"zip"=>35000,"city"=>"RENNES")),
  array("lat"=>46.45296,"lng"=>-0.80598,"data"=>array("drive"=>true,"zip"=>85200,"city"=>"FONTENAY-LE-COMTE")),
  array("lat"=>47.33167,"lng"=>0.7059,"data"=>array("drive"=>true,"zip"=>37170,"city"=>"CHAMBRAY-LÈS-TOURS")),
  array("lat"=>43.52714,"lng"=>-1.46321,"data"=>array("drive"=>true,"zip"=>40220,"city"=>"TARNOS")),
  array("lat"=>48.4289,"lng"=>7.65895,"data"=>array("drive"=>true,"zip"=>67150,"city"=>"ERSTEIN")),
  array("lat"=>48.70225,"lng"=>7.37477,"data"=>array("drive"=>true,"zip"=>67440,"city"=>"MARMOUTIER")),
  array("lat"=>49.59017,"lng"=>3.64668,"data"=>array("drive"=>true,"zip"=>2000,"city"=>"CHAMBRY")),
  array("lat"=>47.62867,"lng"=>7.22401,"data"=>array("drive"=>true,"zip"=>68130,"city"=>"CARSPACH")),
  array("lat"=>50.33414,"lng"=>2.92737,"data"=>array("drive"=>true,"zip"=>62490,"city"=>"FRESNES-LÈS-MONTAUBAN")),
  array("lat"=>46.7003,"lng"=>-1.43078,"data"=>array("drive"=>true,"zip"=>85000,"city"=>"LA ROCHE-SUR-YON")),
  array("lat"=>47.70811,"lng"=>2.6395,"data"=>array("drive"=>false,"zip"=>45500,"city"=>"GIEN")),
  array("lat"=>47.90406,"lng"=>2.03137,"data"=>array("drive"=>false,"zip"=>45430,"city"=>"CHÉCY")),
  array("lat"=>47.21099,"lng"=>-1.61698,"data"=>array("drive"=>true,"zip"=>44800,"city"=>"SAINT-HERBLAIN")),
  array("lat"=>47.22455,"lng"=>-1.63032,"data"=>array("drive"=>true,"zip"=>44800,"city"=>"SAINT-HERBLAIN")),
  array("lat"=>47.55916,"lng"=>-2.50631,"data"=>array("drive"=>true,"zip"=>56190,"city"=>"AMBON")),
  array("lat"=>47.16063,"lng"=>-1.54322,"data"=>array("drive"=>true,"zip"=>44400,"city"=>"REZÉ")),
  array("lat"=>49.53625,"lng"=>0.96334,"data"=>array("drive"=>true,"zip"=>76360,"city"=>"BARENTIN")),
  array("lat"=>49.26747,"lng"=>-0.25976,"data"=>array("drive"=>true,"zip"=>14150,"city"=>"OUISTREHAM")),
  array("lat"=>48.4477,"lng"=>-2.07346,"data"=>array("drive"=>true,"zip"=>22100,"city"=>"QUÉVERT")),
  array("lat"=>49.55026,"lng"=>0.4915,"data"=>array("drive"=>true,"zip"=>76210,"city"=>"GRUCHET-LE-VALASSE")),
  array("lat"=>48.72733,"lng"=>-0.58193,"data"=>array("drive"=>true,"zip"=>61100,"city"=>"FLERS")),
  array("lat"=>49.39374,"lng"=>1.05964,"data"=>array("drive"=>true,"zip"=>76800,"city"=>"SAINT-ÉTIENNE-DU-ROUVRAY")),
  array("lat"=>49.02828,"lng"=>1.1469,"data"=>array("drive"=>false,"zip"=>27000,"city"=>"ÉVREUX")),
  array("lat"=>49.0121,"lng"=>1.1697,"data"=>array("drive"=>true,"zip"=>27000,"city"=>"ÉVREUX")),
  array("lat"=>47.82351,"lng"=>-0.70198,"data"=>array("drive"=>true,"zip"=>53200,"city"=>"CHÂTEAU-GONTIER")),
  array("lat"=>48.74884,"lng"=>-0.02874,"data"=>array("drive"=>true,"zip"=>61200,"city"=>"ARGENTAN")),
  array("lat"=>49.44542,"lng"=>1.07237,"data"=>array("drive"=>true,"zip"=>76000,"city"=>"ROUEN")),
  array("lat"=>47.80748,"lng"=>1.07242,"data"=>array("drive"=>true,"zip"=>41100,"city"=>"SAINT-OUEN")),
  array("lat"=>49.49306,"lng"=>0.12974,"data"=>array("drive"=>true,"zip"=>76600,"city"=>"LE HAVRE")),
  array("lat"=>48.18707,"lng"=>2.24893,"data"=>array("drive"=>true,"zip"=>45300,"city"=>"PITHIVIERS")),
  array("lat"=>47.9778,"lng"=>2.7349,"data"=>array("drive"=>true,"zip"=>45200,"city"=>"AMILLY")),
  array("lat"=>48.45025,"lng"=>-4.26449,"data"=>array("drive"=>true,"zip"=>29800,"city"=>"LANDERNEAU")),
  array("lat"=>49.24956,"lng"=>1.18247,"data"=>array("drive"=>true,"zip"=>27100,"city"=>"VAL-DE-REUIL")),
  array("lat"=>48.847,"lng"=>-0.88338,"data"=>array("drive"=>true,"zip"=>14500,"city"=>"VIRE")),
  array("lat"=>49.52869,"lng"=>0.18786,"data"=>array("drive"=>true,"zip"=>76290,"city"=>"MONTIVILLIERS")),
  array("lat"=>46.95257,"lng"=>2.00576,"data"=>array("drive"=>true,"zip"=>36100,"city"=>"ISSOUDUN")),
  array("lat"=>47.70382,"lng"=>-0.05327,"data"=>array("drive"=>true,"zip"=>72200,"city"=>"LA FLÈCHE")),
  array("lat"=>47.8014,"lng"=>3.56724,"data"=>array("drive"=>true,"zip"=>89000,"city"=>"AUXERRE")),
  array("lat"=>49.02895,"lng"=>7.96147,"data"=>array("drive"=>false,"zip"=>67160,"city"=>"WISSEMBOURG")),
  array("lat"=>48.52198,"lng"=>7.69363,"data"=>array("drive"=>true,"zip"=>67118,"city"=>"GEISPOLSHEIM")),
  array("lat"=>48.74606,"lng"=>7.69354,"data"=>array("drive"=>true,"zip"=>67170,"city"=>"BRUMATH")),
  array("lat"=>46.20722,"lng"=>5.23579,"data"=>array("drive"=>true,"zip"=>1000,"city"=>"BOURG-EN-BRESSE")),
  array("lat"=>46.19529,"lng"=>5.22838,"data"=>array("drive"=>false,"zip"=>1000,"city"=>"BOURG-EN-BRESSE")),
  array("lat"=>46.29394,"lng"=>6.07699,"data"=>array("drive"=>true,"zip"=>1170,"city"=>"SÉGNY")),
  array("lat"=>46.22679,"lng"=>5.9921,"data"=>array("drive"=>true,"zip"=>1710,"city"=>"THOIRY")),
  array("lat"=>45.69762,"lng"=>5.01367,"data"=>array("drive"=>true,"zip"=>69720,"city"=>"SAINT-BONNET-DE-MURE")),
  array("lat"=>43.76626,"lng"=>7.19933,"data"=>array("drive"=>true,"zip"=>6510,"city"=>"GATTIÈRES")),
  array("lat"=>43.42164,"lng"=>5.05497,"data"=>array("drive"=>true,"zip"=>13500,"city"=>"MARTIGUES")),
  array("lat"=>43.53268,"lng"=>6.93265,"data"=>array("drive"=>false,"zip"=>6210,"city"=>"MANDELIEU-LA-NAPOULE")),
  array("lat"=>43.61536,"lng"=>6.97177,"data"=>array("drive"=>true,"zip"=>6250,"city"=>"MOUGINS")),
  array("lat"=>45.37814,"lng"=>4.27377,"data"=>array("drive"=>true,"zip"=>42700,"city"=>"FIRMINY")),
  array("lat"=>43.38815,"lng"=>5.59941,"data"=>array("drive"=>false,"zip"=>13112,"city"=>"LA DESTROUSSE")),
  array("lat"=>43.41947,"lng"=>5.36533,"data"=>array("drive"=>true,"zip"=>13480,"city"=>"CABRIÈS")),
  array("lat"=>45.69263,"lng"=>5.89488,"data"=>array("drive"=>true,"zip"=>73100,"city"=>"AIX-LES-BAINS")),
  array("lat"=>43.48487,"lng"=>5.22238,"data"=>array("drive"=>true,"zip"=>13340,"city"=>"ROGNAC")),
  array("lat"=>45.52242,"lng"=>4.29318,"data"=>array("drive"=>true,"zip"=>42480,"city"=>"LA FOUILLOUSE")),
  array("lat"=>45.57274,"lng"=>5.95168,"data"=>array("drive"=>false,"zip"=>73230,"city"=>"SAINT-ALBAN-LEYSSE")),
  array("lat"=>45.62342,"lng"=>6.77761,"data"=>array("drive"=>true,"zip"=>73700,"city"=>"BOURG-SAINT-MAURICE")),
  array("lat"=>45.59279,"lng"=>5.89805,"data"=>array("drive"=>true,"zip"=>73000,"city"=>"CHAMBÉRY")),
  array("lat"=>45.75765,"lng"=>5.7067,"data"=>array("drive"=>true,"zip"=>1300,"city"=>"BELLEY")),
  array("lat"=>44.53212,"lng"=>4.74583,"data"=>array("drive"=>true,"zip"=>26200,"city"=>"MONTÉLIMAR")),
  array("lat"=>45.46243,"lng"=>4.49481,"data"=>array("drive"=>true,"zip"=>42400,"city"=>"SAINT-CHAMOND")),
  array("lat"=>43.36345,"lng"=>5.34997,"data"=>array("drive"=>false,"zip"=>13015,"city"=>"MARSEILLE")),
  array("lat"=>43.5876,"lng"=>4.99985,"data"=>array("drive"=>true,"zip"=>13140,"city"=>"MIRAMAS")),
  array("lat"=>43.29521,"lng"=>5.3996,"data"=>array("drive"=>true,"zip"=>13005,"city"=>"MARSEILLE")),
  array("lat"=>43.29769,"lng"=>5.38102,"data"=>array("drive"=>false,"zip"=>13001,"city"=>"MARSEILLE")),
  array("lat"=>45.01618,"lng"=>4.87517,"data"=>array("drive"=>true,"zip"=>26600,"city"=>"PONT-DE-L'ISÈRE")),
  array("lat"=>45.57398,"lng"=>4.81087,"data"=>array("drive"=>true,"zip"=>38670,"city"=>"CHASSE-SUR-RHÔNE")),
  array("lat"=>43.14053,"lng"=>6.01929,"data"=>array("drive"=>false,"zip"=>83130,"city"=>"LA GARDE")),
  array("lat"=>48.4444,"lng"=>1.48412,"data"=>array("drive"=>false,"zip"=>28000,"city"=>"CHARTRES")),
  array("lat"=>48.45121,"lng"=>1.51668,"data"=>array("drive"=>false,"zip"=>28000,"city"=>"CHARTRES")),
  array("lat"=>49.32941,"lng"=>1.09975,"data"=>array("drive"=>true,"zip"=>76410,"city"=>"TOURVILLE-LA-RIVIÈRE")),
  array("lat"=>49.2896,"lng"=>1.03598,"data"=>array("drive"=>true,"zip"=>76320,"city"=>"CAUDEBEC-LÈS-ELBEUF")),
  array("lat"=>48.32782,"lng"=>0.80044,"data"=>array("drive"=>true,"zip"=>28400,"city"=>"NOGENT-LE-ROTROU")),
  array("lat"=>48.76171,"lng"=>0.63422,"data"=>array("drive"=>false,"zip"=>61300,"city"=>"L'AIGLE")),
  array("lat"=>49.28479,"lng"=>1.79043,"data"=>array("drive"=>true,"zip"=>27140,"city"=>"GISORS")),
  array("lat"=>46.87485,"lng"=>-1.0254,"data"=>array("drive"=>true,"zip"=>85500,"city"=>"LES HERBIERS")),
  array("lat"=>48.69061,"lng"=>-1.36736,"data"=>array("drive"=>true,"zip"=>50300,"city"=>"AVRANCHES")),
  array("lat"=>48.18117,"lng"=>0.65282,"data"=>array("drive"=>true,"zip"=>72400,"city"=>"LA FERTÉ-BERNARD")),
  array("lat"=>46.99028,"lng"=>-0.19517,"data"=>array("drive"=>true,"zip"=>79100,"city"=>"THOUARS")),
  array("lat"=>48.1205,"lng"=>-1.20926,"data"=>array("drive"=>true,"zip"=>35500,"city"=>"VITRÉ")),
  array("lat"=>49.34739,"lng"=>0.52276,"data"=>array("drive"=>true,"zip"=>27500,"city"=>"PONT-AUDEMER")),
  array("lat"=>48.56253,"lng"=>-3.16595,"data"=>array("drive"=>true,"zip"=>22200,"city"=>"GUINGAMP")),
  array("lat"=>46.85411,"lng"=>-1.89561,"data"=>array("drive"=>true,"zip"=>85300,"city"=>"CHALLANS")),
  array("lat"=>46.64912,"lng"=>-0.22374,"data"=>array("drive"=>true,"zip"=>79200,"city"=>"PARTHENAY")),
  array("lat"=>48.74614,"lng"=>-3.46154,"data"=>array("drive"=>true,"zip"=>22300,"city"=>"LANNION")),
  array("lat"=>47.40362,"lng"=>1.01745,"data"=>array("drive"=>true,"zip"=>37400,"city"=>"AMBOISE")),
  array("lat"=>47.37771,"lng"=>1.73665,"data"=>array("drive"=>true,"zip"=>41200,"city"=>"ROMORANTIN-LANTHENAY")),
  array("lat"=>48.58795,"lng"=>-3.81588,"data"=>array("drive"=>true,"zip"=>29600,"city"=>"MORLAIX")),
  array("lat"=>47.70114,"lng"=>-1.40419,"data"=>array("drive"=>true,"zip"=>44110,"city"=>"CHÂTEAUBRIANT")),
  array("lat"=>48.05324,"lng"=>-2.96002,"data"=>array("drive"=>true,"zip"=>56300,"city"=>"PONTIVY")),
  array("lat"=>47.09679,"lng"=>-1.28171,"data"=>array("drive"=>true,"zip"=>44190,"city"=>"CLISSON")),
  array("lat"=>48.6347,"lng"=>-1.98982,"data"=>array("drive"=>true,"zip"=>35400,"city"=>"SAINT-MALO")),
  array("lat"=>47.9377,"lng"=>1.89409,"data"=>array("drive"=>true,"zip"=>45400,"city"=>"FLEURY-LES-AUBRAIS")),
  array("lat"=>47.3779,"lng"=>0.65709,"data"=>array("drive"=>false,"zip"=>37520,"city"=>"LA RICHE")),
  array("lat"=>48.27737,"lng"=>-3.55243,"data"=>array("drive"=>true,"zip"=>29270,"city"=>"CARHAIX-PLOUGUER")),
  array("lat"=>47.09176,"lng"=>2.4212,"data"=>array("drive"=>true,"zip"=>18000,"city"=>"BOURGES")),
  array("lat"=>48.17589,"lng"=>6.44752,"data"=>array("drive"=>false,"zip"=>88000,"city"=>"ÉPINAL")),
  array("lat"=>48.94794,"lng"=>2.66734,"data"=>array("drive"=>false,"zip"=>77410,"city"=>"CLAYE-SOUILLY")),
  array("lat"=>48.61631,"lng"=>2.629,"data"=>array("drive"=>false,"zip"=>77550,"city"=>"RÉAU")),
  array("lat"=>43.18316,"lng"=>3.0047,"data"=>array("drive"=>false,"zip"=>11100,"city"=>"NARBONNE")),
  array("lat"=>43.52664,"lng"=>-1.52085,"data"=>array("drive"=>false,"zip"=>64600,"city"=>"ANGLET")),
  array("lat"=>43.39914,"lng"=>-1.64043,"data"=>array("drive"=>true,"zip"=>64500,"city"=>"SAINT-JEAN-DE-LUZ")),
  array("lat"=>43.49236,"lng"=>-1.45251,"data"=>array("drive"=>true,"zip"=>64100,"city"=>"BAYONNE")),
  array("lat"=>43.94049,"lng"=>4.5747,"data"=>array("drive"=>true,"zip"=>30210,"city"=>"REMOULINS")),
  array("lat"=>45.18965,"lng"=>0.76522,"data"=>array("drive"=>true,"zip"=>24750,"city"=>"TRÉLISSAC")),
  array("lat"=>45.14758,"lng"=>1.48169,"data"=>array("drive"=>true,"zip"=>19100,"city"=>"BRIVE-LA-GAILLARDE")),
  array("lat"=>44.54311,"lng"=>-0.25242,"data"=>array("drive"=>true,"zip"=>33210,"city"=>"LANGON")),
  array("lat"=>47.07371,"lng"=>-0.84275,"data"=>array("drive"=>true,"zip"=>49300,"city"=>"CHOLET")),
  array("lat"=>47.04603,"lng"=>-0.89599,"data"=>array("drive"=>true,"zip"=>49300,"city"=>"CHOLET")),
  array("lat"=>44.0375,"lng"=>1.38022,"data"=>array("drive"=>true,"zip"=>82000,"city"=>"MONTAUBAN")),
  array("lat"=>44.14998,"lng"=>1.52504,"data"=>array("drive"=>true,"zip"=>82300,"city"=>"CAUSSADE")),
  array("lat"=>45.30648,"lng"=>3.37712,"data"=>array("drive"=>true,"zip"=>43100,"city"=>"BRIOUDE")),
  array("lat"=>47.66047,"lng"=>-2.79238,"data"=>array("drive"=>true,"zip"=>56000,"city"=>"VANNES")),
  array("lat"=>48.73216,"lng"=>0.91992,"data"=>array("drive"=>false,"zip"=>27130,"city"=>"VERNEUIL-SUR-AVRE")),
  array("lat"=>47.43223,"lng"=>-2.08352,"data"=>array("drive"=>true,"zip"=>44160,"city"=>"PONTCHÂTEAU")),
  array("lat"=>44.12719,"lng"=>4.07953,"data"=>array("drive"=>false,"zip"=>30100,"city"=>"ALÈS")),
  array("lat"=>44.10886,"lng"=>4.09774,"data"=>array("drive"=>true,"zip"=>30100,"city"=>"ALÈS")),
  array("lat"=>43.45355,"lng"=>3.42053,"data"=>array("drive"=>true,"zip"=>34120,"city"=>"PÉZENAS")),
  array("lat"=>48.94601,"lng"=>4.37613,"data"=>array("drive"=>true,"zip"=>51000,"city"=>"CHÂLONS-EN-CHAMPAGNE")),
  array("lat"=>48.74493,"lng"=>6.14804,"data"=>array("drive"=>false,"zip"=>54390,"city"=>"FROUARD")),
  array("lat"=>49.64726,"lng"=>2.58702,"data"=>array("drive"=>false,"zip"=>80500,"city"=>"MONTDIDIER")),
  array("lat"=>49.70763,"lng"=>2.77451,"data"=>array("drive"=>false,"zip"=>80700,"city"=>"ROYE")),
  array("lat"=>46.31269,"lng"=>-0.47926,"data"=>array("drive"=>true,"zip"=>79000,"city"=>"NIORT")),
  array("lat"=>47.37263,"lng"=>-1.19489,"data"=>array("drive"=>true,"zip"=>44150,"city"=>"SAINT-GÉRÉON")),
  array("lat"=>47.76512,"lng"=>1.61189,"data"=>array("drive"=>true,"zip"=>45190,"city"=>"TAVERS")),
  array("lat"=>46.34568,"lng"=>2.60137,"data"=>array("drive"=>false,"zip"=>3100,"city"=>"MONTLUÇON")),
  array("lat"=>43.62327,"lng"=>3.43729,"data"=>array("drive"=>true,"zip"=>34800,"city"=>"CLERMONT-L'HÉRAULT")),
  array("lat"=>44.77819,"lng"=>-0.57143,"data"=>array("drive"=>true,"zip"=>33140,"city"=>"VILLENAVE-D'ORNON")),
  array("lat"=>49.74025,"lng"=>4.70811,"data"=>array("drive"=>false,"zip"=>8000,"city"=>"CHARLEVILLE-MÉZIÈRES")),
  array("lat"=>44.91353,"lng"=>2.4413,"data"=>array("drive"=>true,"zip"=>15000,"city"=>"AURILLAC")),
  array("lat"=>43.63204,"lng"=>5.10025,"data"=>array("drive"=>true,"zip"=>13300,"city"=>"SALON-DE-PROVENCE")),
  array("lat"=>43.63809,"lng"=>5.09909,"data"=>array("drive"=>false,"zip"=>13300,"city"=>"SALON-DE-PROVENCE")),
  array("lat"=>43.62881,"lng"=>5.11294,"data"=>array("drive"=>true,"zip"=>13300,"city"=>"SALON-DE-PROVENCE")),
  array("lat"=>43.13678,"lng"=>6.00456,"data"=>array("drive"=>true,"zip"=>83160,"city"=>"LA VALETTE-DU-VAR")),
  array("lat"=>43.12026,"lng"=>5.93585,"data"=>array("drive"=>false,"zip"=>83000,"city"=>"TOULON")),
  array("lat"=>43.69549,"lng"=>7.27532,"data"=>array("drive"=>false,"zip"=>6300,"city"=>"NICE")),
  array("lat"=>43.69503,"lng"=>7.26598,"data"=>array("drive"=>false,"zip"=>6000,"city"=>"NICE")),
  array("lat"=>45.74965,"lng"=>5.18672,"data"=>array("drive"=>true,"zip"=>38230,"city"=>"TIGNIEU-JAMEYZIEU")),
  array("lat"=>45.35929,"lng"=>5.59161,"data"=>array("drive"=>true,"zip"=>38500,"city"=>"VOIRON")),
  array("lat"=>44.94182,"lng"=>4.91753,"data"=>array("drive"=>true,"zip"=>26000,"city"=>"VALENCE")),
  array("lat"=>43.95763,"lng"=>4.85822,"data"=>array("drive"=>false,"zip"=>84130,"city"=>"LE PONTET")),
  array("lat"=>45.85872,"lng"=>6.14174,"data"=>array("drive"=>true,"zip"=>74320,"city"=>"SÉVRIER")),
  array("lat"=>45.65625,"lng"=>6.36344,"data"=>array("drive"=>true,"zip"=>73200,"city"=>"GILLY-SUR-ISÈRE")),
  array("lat"=>46.80516,"lng"=>1.69815,"data"=>array("drive"=>true,"zip"=>36000,"city"=>"CHÂTEAUROUX")),
  array("lat"=>48.64877,"lng"=>4.95863,"data"=>array("drive"=>true,"zip"=>52100,"city"=>"SAINT-DIZIER")),
  array("lat"=>48.62586,"lng"=>4.96505,"data"=>array("drive"=>true,"zip"=>52100,"city"=>"SAINT-DIZIER")),
  array("lat"=>48.74646,"lng"=>1.34621,"data"=>array("drive"=>false,"zip"=>28100,"city"=>"DREUX")),
  array("lat"=>44.56858,"lng"=>6.10331,"data"=>array("drive"=>true,"zip"=>5000,"city"=>"GAP")),
  array("lat"=>47.26543,"lng"=>-0.09157,"data"=>array("drive"=>true,"zip"=>49400,"city"=>"SAUMUR")),
  array("lat"=>46.83966,"lng"=>0.54644,"data"=>array("drive"=>true,"zip"=>86100,"city"=>"CHÂTELLERAULT")),
  array("lat"=>47.88127,"lng"=>-4.21796,"data"=>array("drive"=>false,"zip"=>29120,"city"=>"PONT-L'ABBÉ")),
  array("lat"=>50.16915,"lng"=>3.23248,"data"=>array("drive"=>true,"zip"=>59400,"city"=>"CAMBRAI")),
  array("lat"=>49.91121,"lng"=>1.07823,"data"=>array("drive"=>true,"zip"=>76200,"city"=>"DIEPPE")),
  array("lat"=>47.23997,"lng"=>2.09244,"data"=>array("drive"=>true,"zip"=>18100,"city"=>"VIERZON")),
  array("lat"=>48.04575,"lng"=>-1.60315,"data"=>array("drive"=>false,"zip"=>35770,"city"=>"VERN-SUR-SEICHE")),
  array("lat"=>49.3091,"lng"=>-1.10435,"data"=>array("drive"=>true,"zip"=>14230,"city"=>"ISIGNY-SUR-MER")),
  array("lat"=>47.11203,"lng"=>-2.07228,"data"=>array("drive"=>true,"zip"=>44210,"city"=>"PORNIC")),
  array("lat"=>48.20149,"lng"=>-1.7295,"data"=>array("drive"=>true,"zip"=>35520,"city"=>"LA MÉZIÈRE")),
  array("lat"=>49.09657,"lng"=>1.4642,"data"=>array("drive"=>true,"zip"=>27200,"city"=>"VERNON")),
  array("lat"=>48.17689,"lng"=>-1.9195,"data"=>array("drive"=>true,"zip"=>35137,"city"=>"PLEUMELEUC")),
  array("lat"=>46.14226,"lng"=>3.41565,"data"=>array("drive"=>true,"zip"=>3200,"city"=>"VICHY")),
  array("lat"=>46.54005,"lng"=>3.34363,"data"=>array("drive"=>false,"zip"=>3000,"city"=>"MOULINS")),
  array("lat"=>48.20564,"lng"=>3.27694,"data"=>array("drive"=>true,"zip"=>89100,"city"=>"SENS")),
  array("lat"=>48.19324,"lng"=>3.30414,"data"=>array("drive"=>true,"zip"=>89100,"city"=>"SENS")),
  array("lat"=>48.82776,"lng"=>7.75762,"data"=>array("drive"=>true,"zip"=>67500,"city"=>"HAGUENAU")),
  array("lat"=>48.27541,"lng"=>7.46269,"data"=>array("drive"=>true,"zip"=>67600,"city"=>"SÉLESTAT")),
  array("lat"=>46.06609,"lng"=>4.05525,"data"=>array("drive"=>true,"zip"=>42300,"city"=>"MABLY")),
  array("lat"=>48.0593,"lng"=>-1.88073,"data"=>array("drive"=>true,"zip"=>35310,"city"=>"BRÉAL-SOUS-MONTFORT")),
  array("lat"=>44.61628,"lng"=>-1.13558,"data"=>array("drive"=>true,"zip"=>33260,"city"=>"LA TESTE-DE-BUCH")),
  array("lat"=>46.48827,"lng"=>-1.74664,"data"=>array("drive"=>true,"zip"=>85180,"city"=>"CHÂTEAU-D'OLONNE")),
  array("lat"=>49.16435,"lng"=>-0.42315,"data"=>array("drive"=>false,"zip"=>14760,"city"=>"BRETTEVILLE-SUR-ODON")),
  array("lat"=>49.16435,"lng"=>-0.42315,"data"=>array("drive"=>true,"zip"=>14760,"city"=>"BRETTEVILLE-SUR-ODON")),
  array("lat"=>49.11662,"lng"=>7.09562,"data"=>array("drive"=>true,"zip"=>57200,"city"=>"SARREGUEMINES")),
  array("lat"=>44.05047,"lng"=>5.04046,"data"=>array("drive"=>true,"zip"=>84200,"city"=>"CARPENTRAS")),
  array("lat"=>45.58952,"lng"=>5.2573,"data"=>array("drive"=>true,"zip"=>38300,"city"=>"BOURGOIN-JALLIEU")),
  array("lat"=>45.64363,"lng"=>5.13336,"data"=>array("drive"=>true,"zip"=>38290,"city"=>"LA VERPILLIÈRE")),
  array("lat"=>43.65012,"lng"=>0.59442,"data"=>array("drive"=>true,"zip"=>32000,"city"=>"AUCH")),
  array("lat"=>44.17593,"lng"=>0.63449,"data"=>array("drive"=>true,"zip"=>47550,"city"=>"BOÉ")),
  array("lat"=>44.20555,"lng"=>0.62636,"data"=>array("drive"=>false,"zip"=>47000,"city"=>"AGEN")),
  array("lat"=>44.18983,"lng"=>0.61384,"data"=>array("drive"=>true,"zip"=>47000,"city"=>"AGEN")),
  array("lat"=>49.17549,"lng"=>6.88154,"data"=>array("drive"=>true,"zip"=>57600,"city"=>"FORBACH")),
  array("lat"=>45.99922,"lng"=>4.73415,"data"=>array("drive"=>true,"zip"=>69400,"city"=>"VILLEFRANCHE-SUR-SAÔNE")),
  array("lat"=>43.44477,"lng"=>6.70256,"data"=>array("drive"=>true,"zip"=>83480,"city"=>"PUGET-SUR-ARGENS")),
  array("lat"=>43.31744,"lng"=>6.63152,"data"=>array("drive"=>true,"zip"=>83120,"city"=>"SAINTE-MAXIME")),
  array("lat"=>43.82719,"lng"=>5.03515,"data"=>array("drive"=>true,"zip"=>84300,"city"=>"CAVAILLON")),
  array("lat"=>47.11209,"lng"=>2.3779,"data"=>array("drive"=>true,"zip"=>18230,"city"=>"SAINT-DOULCHARD")),
  array("lat"=>48.90891,"lng"=>-0.20495,"data"=>array("drive"=>false,"zip"=>14700,"city"=>"FALAISE")),
  array("lat"=>46.4614,"lng"=>-1.13504,"data"=>array("drive"=>true,"zip"=>85400,"city"=>"LUÇON")),
  array("lat"=>46.6822,"lng"=>4.36231,"data"=>array("drive"=>true,"zip"=>71300,"city"=>"MONTCEAU-LES-MINES")),
  array("lat"=>44.46648,"lng"=>1.42802,"data"=>array("drive"=>true,"zip"=>46000,"city"=>"CAHORS")),
  array("lat"=>44.40372,"lng"=>0.68295,"data"=>array("drive"=>true,"zip"=>47300,"city"=>"BIAS")),
  array("lat"=>43.8773,"lng"=>-0.46615,"data"=>array("drive"=>true,"zip"=>40000,"city"=>"MONT-DE-MARSAN")),
  array("lat"=>43.90271,"lng"=>-0.48042,"data"=>array("drive"=>true,"zip"=>40000,"city"=>"MONT-DE-MARSAN")),
  array("lat"=>45.19472,"lng"=>0.66071,"data"=>array("drive"=>true,"zip"=>24430,"city"=>"MARSAC-SUR-L'ISLE")),
  array("lat"=>50.28273,"lng"=>2.73737,"data"=>array("drive"=>true,"zip"=>62000,"city"=>"DAINVILLE")),
  array("lat"=>50.69981,"lng"=>1.6083,"data"=>array("drive"=>true,"zip"=>62230,"city"=>"OUTREAU")),
  array("lat"=>50.72687,"lng"=>1.64407,"data"=>array("drive"=>true,"zip"=>62280,"city"=>"SAINT-MARTIN-BOULOGNE")),
  array("lat"=>48.45878,"lng"=>7.49315,"data"=>array("drive"=>true,"zip"=>67210,"city"=>"OBERNAI")),
  array("lat"=>48.1088,"lng"=>5.14058,"data"=>array("drive"=>true,"zip"=>52000,"city"=>"CHAUMONT")),
  array("lat"=>49.02502,"lng"=>3.94507,"data"=>array("drive"=>true,"zip"=>51530,"city"=>"PIERRY")),
  array("lat"=>49.69861,"lng"=>4.92847,"data"=>array("drive"=>true,"zip"=>8200,"city"=>"SEDAN")),
  array("lat"=>48.27759,"lng"=>6.96018,"data"=>array("drive"=>true,"zip"=>88100,"city"=>"SAINT-DIÉ-DES-VOSGES")),
  array("lat"=>49.23409,"lng"=>2.46697,"data"=>array("drive"=>true,"zip"=>60740,"city"=>"SAINT-MAXIMIN")),
  array("lat"=>49.37046,"lng"=>3.31379,"data"=>array("drive"=>true,"zip"=>2200,"city"=>"SOISSONS")),
  array("lat"=>49.25977,"lng"=>2.45245,"data"=>array("drive"=>true,"zip"=>60160,"city"=>"MONTATAIRE")),
  array("lat"=>46.34896,"lng"=>6.4319,"data"=>array("drive"=>true,"zip"=>74200,"city"=>"ANTHY-SUR-LÉMAN")),
  array("lat"=>46.18136,"lng"=>6.23066,"data"=>array("drive"=>true,"zip"=>74100,"city"=>"ÉTREMBIÈRES")),
  array("lat"=>49.63388,"lng"=>-1.61717,"data"=>array("drive"=>true,"zip"=>50100,"city"=>"CHERBOURG-OCTEVILLE")),
  array("lat"=>48.42813,"lng"=>1.51306,"data"=>array("drive"=>true,"zip"=>28630,"city"=>"LE COUDRAY")),
  array("lat"=>48.44685,"lng"=>1.44533,"data"=>array("drive"=>false,"zip"=>28300,"city"=>"MAINVILLIERS")),
  array("lat"=>49.66141,"lng"=>-1.68572,"data"=>array("drive"=>true,"zip"=>50120,"city"=>"ÉQUEURDREVILLE-HAINNEVILLE")),
  array("lat"=>48.43334,"lng"=>0.0619,"data"=>array("drive"=>true,"zip"=>61250,"city"=>"CONDÉ-SUR-SARTHE")),
  array("lat"=>49.1436,"lng"=>0.264,"data"=>array("drive"=>true,"zip"=>14100,"city"=>"LISIEUX")),
  array("lat"=>49.14455,"lng"=>0.26151,"data"=>array("drive"=>false,"zip"=>14100,"city"=>"LISIEUX")),
  array("lat"=>49.06889,"lng"=>-1.43112,"data"=>array("drive"=>true,"zip"=>50200,"city"=>"COUTANCES")),
  array("lat"=>48.34627,"lng"=>-1.18102,"data"=>array("drive"=>true,"zip"=>35300,"city"=>"FOUGÈRES")),
  array("lat"=>48.49412,"lng"=>-2.72529,"data"=>array("drive"=>true,"zip"=>22360,"city"=>"LANGUEUX")),
  array("lat"=>48.53367,"lng"=>-2.75628,"data"=>array("drive"=>true,"zip"=>22190,"city"=>"PLÉRIN")),
  array("lat"=>48.55891,"lng"=>-1.49087,"data"=>array("drive"=>false,"zip"=>50170,"city"=>"PONTORSON")),
  array("lat"=>45.95467,"lng"=>-0.52921,"data"=>array("drive"=>true,"zip"=>17400,"city"=>"SAINT-JEAN-D'ANGÉLY")),
  array("lat"=>43.2693,"lng"=>3.28289,"data"=>array("drive"=>true,"zip"=>34410,"city"=>"SÉRIGNAN")),
  array("lat"=>43.68239,"lng"=>4.15191,"data"=>array("drive"=>true,"zip"=>34400,"city"=>"LUNEL")),
  array("lat"=>43.56924,"lng"=>3.83902,"data"=>array("drive"=>true,"zip"=>34430,"city"=>"SAINT-JEAN-DE-VÉDAS")),
  array("lat"=>43.46112,"lng"=>3.69264,"data"=>array("drive"=>true,"zip"=>34540,"city"=>"BALARUC-LE-VIEUX")),
  array("lat"=>43.65659,"lng"=>3.99834,"data"=>array("drive"=>true,"zip"=>34670,"city"=>"BAILLARGUES")),
  array("lat"=>43.30392,"lng"=>3.48483,"data"=>array("drive"=>true,"zip"=>34300,"city"=>"AGDE")),
  array("lat"=>43.58353,"lng"=>3.92977,"data"=>array("drive"=>false,"zip"=>34970,"city"=>"LATTES")),
  array("lat"=>43.58335,"lng"=>3.9267,"data"=>array("drive"=>true,"zip"=>34970,"city"=>"LATTES")),
  array("lat"=>45.95871,"lng"=>-0.97737,"data"=>array("drive"=>true,"zip"=>17300,"city"=>"ROCHEFORT")),
  array("lat"=>45.74002,"lng"=>-0.66216,"data"=>array("drive"=>true,"zip"=>17100,"city"=>"SAINTES")),
  array("lat"=>46.25419,"lng"=>5.64303,"data"=>array("drive"=>true,"zip"=>1100,"city"=>"OYONNAX")),
  array("lat"=>50.69232,"lng"=>2.8704,"data"=>array("drive"=>true,"zip"=>59280,"city"=>"ARMENTIÈRES")),
  array("lat"=>47.08231,"lng"=>5.47542,"data"=>array("drive"=>true,"zip"=>39100,"city"=>"DOLE")),
  array("lat"=>44.83553,"lng"=>0.44856,"data"=>array("drive"=>true,"zip"=>24100,"city"=>"BERGERAC")),
  array("lat"=>43.66845,"lng"=>-1.28273,"data"=>array("drive"=>true,"zip"=>40230,"city"=>"SAINT-VINCENT-DE-TYROSSE")),
  array("lat"=>44.41121,"lng"=>-1.16901,"data"=>array("drive"=>true,"zip"=>40600,"city"=>"BISCARROSSE")),
  array("lat"=>49.10036,"lng"=>-1.08275,"data"=>array("drive"=>true,"zip"=>50000,"city"=>"SAINT-LÔ")),
  array("lat"=>48.7711,"lng"=>-3.03922,"data"=>array("drive"=>true,"zip"=>22500,"city"=>"PAIMPOL")),
  array("lat"=>47.93985,"lng"=>0.23237,"data"=>array("drive"=>true,"zip"=>72230,"city"=>"MULSANNE")),
  array("lat"=>48.1025,"lng"=>-1.46488,"data"=>array("drive"=>true,"zip"=>35530,"city"=>"SERVON-SUR-VILAINE")),
  array("lat"=>47.6635,"lng"=>-3.00718,"data"=>array("drive"=>true,"zip"=>56400,"city"=>"AURAY")),
  array("lat"=>44.37213,"lng"=>2.59181,"data"=>array("drive"=>true,"zip"=>12850,"city"=>"ONET-LE-CHÂTEAU")),
  array("lat"=>45.62354,"lng"=>-1.00287,"data"=>array("drive"=>true,"zip"=>17200,"city"=>"ROYAN")),
  array("lat"=>48.95996,"lng"=>4.31652,"data"=>array("drive"=>true,"zip"=>51510,"city"=>"FAGNIÈRES")),
  array("lat"=>47.83772,"lng"=>-0.29898,"data"=>array("drive"=>true,"zip"=>72300,"city"=>"SOLESMES")),
  array("lat"=>48.05079,"lng"=>0.17075,"data"=>array("drive"=>true,"zip"=>72650,"city"=>"SAINT-SATURNIN")),
  array("lat"=>45.16874,"lng"=>1.56076,"data"=>array("drive"=>true,"zip"=>19360,"city"=>"MALEMORT-SUR-CORRÈZE")),
  array("lat"=>43.95464,"lng"=>2.15499,"data"=>array("drive"=>true,"zip"=>81380,"city"=>"LESCURE-D'ALBIGEOIS")),
  array("lat"=>46.33162,"lng"=>4.84198,"data"=>array("drive"=>true,"zip"=>71000,"city"=>"SANCÉ")),
  array("lat"=>46.21523,"lng"=>5.21492,"data"=>array("drive"=>false,"zip"=>1440,"city"=>"VIRIAT")),
  array("lat"=>47.57137,"lng"=>1.37103,"data"=>array("drive"=>true,"zip"=>41350,"city"=>"VINEUIL")),
  array("lat"=>46.40772,"lng"=>-0.22409,"data"=>array("drive"=>true,"zip"=>79400,"city"=>"AZAY-LE-BRÛLÉ")),
  array("lat"=>46.53688,"lng"=>0.28762,"data"=>array("drive"=>false,"zip"=>86240,"city"=>"CROUTELLE")),
  array("lat"=>47.2927,"lng"=>-1.74291,"data"=>array("drive"=>true,"zip"=>44360,"city"=>"VIGNEUX-DE-BRETAGNE")),
  array("lat"=>47.18821,"lng"=>-1.58899,"data"=>array("drive"=>true,"zip"=>44340,"city"=>"BOUGUENAIS")),
  array("lat"=>47.16363,"lng"=>-1.68076,"data"=>array("drive"=>false,"zip"=>44830,"city"=>"BOUAYE")),
  array("lat"=>44.3863,"lng"=>5.00689,"data"=>array("drive"=>true,"zip"=>84600,"city"=>"VALRÉAS")),
  array("lat"=>47.59991,"lng"=>6.85826,"data"=>array("drive"=>true,"zip"=>90400,"city"=>"ANDELNANS")),
  array("lat"=>47.97876,"lng"=>3.37711,"data"=>array("drive"=>true,"zip"=>89300,"city"=>"JOIGNY")),
  array("lat"=>47.2938,"lng"=>-2.39774,"data"=>array("drive"=>true,"zip"=>44350,"city"=>"GUÉRANDE")),
  array("lat"=>48.13013,"lng"=>-1.64109,"data"=>array("drive"=>true,"zip"=>35700,"city"=>"RENNES")),
  array("lat"=>47.65131,"lng"=>-2.72394,"data"=>array("drive"=>true,"zip"=>56860,"city"=>"SÉNÉ")),
  array("lat"=>46.17324,"lng"=>-1.16896,"data"=>array("drive"=>true,"zip"=>17140,"city"=>"LAGORD")),
  array("lat"=>47.1874,"lng"=>-1.47013,"data"=>array("drive"=>true,"zip"=>44115,"city"=>"BASSE-GOULAINE")),
  array("lat"=>45.62189,"lng"=>0.10952,"data"=>array("drive"=>false,"zip"=>16400,"city"=>"LA COURONNE")),
  array("lat"=>48.22374,"lng"=>-1.50125,"data"=>array("drive"=>true,"zip"=>35340,"city"=>"LIFFRÉ")),
  array("lat"=>46.3379,"lng"=>-0.41275,"data"=>array("drive"=>true,"zip"=>79000,"city"=>"NIORT")),
  array("lat"=>46.84991,"lng"=>-0.47008,"data"=>array("drive"=>true,"zip"=>79300,"city"=>"BRESSUIRE")),
  array("lat"=>46.69384,"lng"=>-1.91407,"data"=>array("drive"=>true,"zip"=>85800,"city"=>"SAINT-GILLES-CROIX-DE-VIE")),
  array("lat"=>46.64778,"lng"=>-1.4366,"data"=>array("drive"=>true,"zip"=>85000,"city"=>"LA ROCHE-SUR-YON")),
  array("lat"=>49.2,"lng"=>-0.36061,"data"=>array("drive"=>false,"zip"=>14000,"city"=>"CAEN")),
  array("lat"=>49.20966,"lng"=>-0.36321,"data"=>array("drive"=>false,"zip"=>14000,"city"=>"CAEN")),
  array("lat"=>48.28511,"lng"=>-0.62396,"data"=>array("drive"=>true,"zip"=>53100,"city"=>"MAYENNE")),
  array("lat"=>49.23939,"lng"=>3.09899,"data"=>array("drive"=>true,"zip"=>2600,"city"=>"VILLERS-COTTERÊTS")),
  array("lat"=>50.51654,"lng"=>2.62337,"data"=>array("drive"=>true,"zip"=>62232,"city"=>"FOUQUIÈRES-LÈS-BÉTHUNE")),
  array("lat"=>48.3702,"lng"=>5.70637,"data"=>array("drive"=>true,"zip"=>88300,"city"=>"NEUFCHÂTEAU")),
  array("lat"=>49.14623,"lng"=>2.44108,"data"=>array("drive"=>true,"zip"=>60260,"city"=>"LAMORLAYE")),
  array("lat"=>44.60835,"lng"=>2.01569,"data"=>array("drive"=>true,"zip"=>46100,"city"=>"FIGEAC")),
  array("lat"=>44.83058,"lng"=>-0.57324,"data"=>array("drive"=>false,"zip"=>33000,"city"=>"BORDEAUX")),
  array("lat"=>43.63707,"lng"=>1.37573,"data"=>array("drive"=>true,"zip"=>31700,"city"=>"BLAGNAC")),
  array("lat"=>44.8207,"lng"=>-0.52006,"data"=>array("drive"=>true,"zip"=>33270,"city"=>"FLOIRAC")),
  array("lat"=>42.625,"lng"=>2.4282,"data"=>array("drive"=>true,"zip"=>66500,"city"=>"PRADES")),
  array("lat"=>48.19735,"lng"=>6.47662,"data"=>array("drive"=>true,"zip"=>88000,"city"=>"JEUXEY")),
  array("lat"=>43.89271,"lng"=>1.88001,"data"=>array("drive"=>true,"zip"=>81600,"city"=>"GAILLAC")),
  array("lat"=>43.24172,"lng"=>0.02018,"data"=>array("drive"=>true,"zip"=>65420,"city"=>"IBOS")),
  array("lat"=>46.25365,"lng"=>4.79167,"data"=>array("drive"=>true,"zip"=>71680,"city"=>"CRÊCHES-SUR-SAÔNE")),
  array("lat"=>49.14146,"lng"=>6.80971,"data"=>array("drive"=>true,"zip"=>57800,"city"=>"FREYMING-MERLEBACH")),
  array("lat"=>48.71099,"lng"=>3.73161,"data"=>array("drive"=>true,"zip"=>51120,"city"=>"SÉZANNE")),
  array("lat"=>44.88429,"lng"=>-0.69261,"data"=>array("drive"=>true,"zip"=>33160,"city"=>"SAINT-MÉDARD-EN-JALLES")),
  array("lat"=>44.78576,"lng"=>-0.63614,"data"=>array("drive"=>true,"zip"=>33600,"city"=>"PESSAC")),
  array("lat"=>46.99851,"lng"=>3.10702,"data"=>array("drive"=>false,"zip"=>58180,"city"=>"MARZY")),
  array("lat"=>45.038,"lng"=>3.06353,"data"=>array("drive"=>true,"zip"=>15100,"city"=>"ANDELAT")),
  array("lat"=>47.3578,"lng"=>5.04794,"data"=>array("drive"=>false,"zip"=>21000,"city"=>"DIJON")),
  array("lat"=>45.76411,"lng"=>3.12768,"data"=>array("drive"=>false,"zip"=>63000,"city"=>"CLERMONT-FERRAND")),
  array("lat"=>46.46214,"lng"=>4.08357,"data"=>array("drive"=>true,"zip"=>71600,"city"=>"VITRY-EN-CHAROLLAIS")),
  array("lat"=>46.77443,"lng"=>4.8591,"data"=>array("drive"=>true,"zip"=>71100,"city"=>"CHALON-SUR-SAÔNE")),
  array("lat"=>47.49962,"lng"=>3.90856,"data"=>array("drive"=>true,"zip"=>89200,"city"=>"AVALLON")),
  array("lat"=>47.33954,"lng"=>5.06704,"data"=>array("drive"=>true,"zip"=>21000,"city"=>"DIJON")),
  array("lat"=>46.73024,"lng"=>2.49593,"data"=>array("drive"=>true,"zip"=>18200,"city"=>"SAINT-AMAND-MONTROND")),
  array("lat"=>43.812,"lng"=>4.36212,"data"=>array("drive"=>true,"zip"=>30900,"city"=>"NÎMES")),
  array("lat"=>43.52947,"lng"=>1.35077,"data"=>array("drive"=>true,"zip"=>31270,"city"=>"CUGNAUX")),
  array("lat"=>43.68697,"lng"=>1.40451,"data"=>array("drive"=>true,"zip"=>31150,"city"=>"FENOUILLET")),
  array("lat"=>43.51086,"lng"=>1.37046,"data"=>array("drive"=>true,"zip"=>31120,"city"=>"ROQUES")),
  array("lat"=>43.66181,"lng"=>1.43256,"data"=>array("drive"=>true,"zip"=>31200,"city"=>"TOULOUSE")),
  array("lat"=>43.66809,"lng"=>1.51238,"data"=>array("drive"=>true,"zip"=>31180,"city"=>"ROUFFIAC-TOLOSAN")),
  array("lat"=>43.98803,"lng"=>1.33467,"data"=>array("drive"=>true,"zip"=>82000,"city"=>"MONTAUBAN")),
  array("lat"=>43.91865,"lng"=>2.11764,"data"=>array("drive"=>true,"zip"=>81000,"city"=>"ALBI")),
  array("lat"=>43.60536,"lng"=>1.44842,"data"=>array("drive"=>false,"zip"=>31000,"city"=>"TOULOUSE")),
  array("lat"=>43.61367,"lng"=>3.81035,"data"=>array("drive"=>true,"zip"=>34990,"city"=>"JUVIGNAC")),
  array("lat"=>44.84101,"lng"=>-0.57437,"data"=>array("drive"=>false,"zip"=>33000,"city"=>"BORDEAUX")),
  array("lat"=>50.77126,"lng"=>3.1253,"data"=>array("drive"=>true,"zip"=>59250,"city"=>"HALLUIN")),
  array("lat"=>49.5439,"lng"=>5.8002,"data"=>array("drive"=>false,"zip"=>54350,"city"=>"MONT-SAINT-MARTIN")),
  array("lat"=>49.13385,"lng"=>6.1993,"data"=>array("drive"=>true,"zip"=>57070,"city"=>"SAINT-JULIEN-LÈS-METZ")),
  array("lat"=>50.4323,"lng"=>2.81926,"data"=>array("drive"=>true,"zip"=>62300,"city"=>"LENS")),
  array("lat"=>48.27995,"lng"=>4.04371,"data"=>array("drive"=>true,"zip"=>10120,"city"=>"SAINT-ANDRÉ-LES-VERGERS")),
  array("lat"=>48.61902,"lng"=>6.17515,"data"=>array("drive"=>true,"zip"=>54710,"city"=>"LUDRES")),
  array("lat"=>50.44351,"lng"=>2.94425,"data"=>array("drive"=>true,"zip"=>62710,"city"=>"COURRIÈRES")),
  array("lat"=>49.84914,"lng"=>3.26991,"data"=>array("drive"=>true,"zip"=>2100,"city"=>"SAINT-QUENTIN")),
  array("lat"=>50.30049,"lng"=>2.73885,"data"=>array("drive"=>true,"zip"=>62000,"city"=>"ARRAS")),
  array("lat"=>50.129,"lng"=>3.42547,"data"=>array("drive"=>false,"zip"=>59540,"city"=>"CAUDRY")),
  array("lat"=>48.80025,"lng"=>7.8341,"data"=>array("drive"=>true,"zip"=>67500,"city"=>"HAGUENAU")),
  array("lat"=>49.47593,"lng"=>5.95543,"data"=>array("drive"=>true,"zip"=>57390,"city"=>"AUDUN-LE-TICHE")),
  array("lat"=>49.28624,"lng"=>2.49552,"data"=>array("drive"=>false,"zip"=>60870,"city"=>"VILLERS-SAINT-PAUL")),
  array("lat"=>49.14912,"lng"=>6.15995,"data"=>array("drive"=>true,"zip"=>57140,"city"=>"WOIPPY")),
  array("lat"=>48.52521,"lng"=>7.49806,"data"=>array("drive"=>true,"zip"=>67120,"city"=>"DORLISHEIM")),
  array("lat"=>50.47945,"lng"=>2.96617,"data"=>array("drive"=>false,"zip"=>62220,"city"=>"CARVIN")),
  array("lat"=>50.10121,"lng"=>1.85714,"data"=>array("drive"=>true,"zip"=>80100,"city"=>"ABBEVILLE")),
  array("lat"=>48.07079,"lng"=>7.36641,"data"=>array("drive"=>true,"zip"=>68000,"city"=>"COLMAR")),
  array("lat"=>43.02988,"lng"=>2.96535,"data"=>array("drive"=>true,"zip"=>11130,"city"=>"SIGEAN")),
  array("lat"=>43.57373,"lng"=>1.49414,"data"=>array("drive"=>true,"zip"=>31500,"city"=>"TOULOUSE")),
  array("lat"=>44.6366,"lng"=>-0.95766,"data"=>array("drive"=>true,"zip"=>33380,"city"=>"BIGANOS")),
  array("lat"=>43.5915,"lng"=>2.21683,"data"=>array("drive"=>true,"zip"=>81100,"city"=>"CASTRES")),
  array("lat"=>44.80004,"lng"=>-0.59541,"data"=>array("drive"=>true,"zip"=>33400,"city"=>"TALENCE")),
  array("lat"=>43.59462,"lng"=>1.41901,"data"=>array("drive"=>true,"zip"=>31300,"city"=>"TOULOUSE")),
  array("lat"=>43.55012,"lng"=>1.50215,"data"=>array("drive"=>true,"zip"=>31670,"city"=>"LABÈGE")),
  array("lat"=>43.3721,"lng"=>-0.62537,"data"=>array("drive"=>true,"zip"=>64150,"city"=>"MOURENX")),
  array("lat"=>43.40985,"lng"=>3.70663,"data"=>array("drive"=>true,"zip"=>34200,"city"=>"SÈTE")),
  array("lat"=>43.2978,"lng"=>3.47606,"data"=>array("drive"=>true,"zip"=>34300,"city"=>"AGDE")),
  array("lat"=>43.71027,"lng"=>-1.04371,"data"=>array("drive"=>true,"zip"=>40100,"city"=>"DAX")),
  array("lat"=>44.09113,"lng"=>3.08218,"data"=>array("drive"=>true,"zip"=>12100,"city"=>"MILLAU")),
  array("lat"=>43.78358,"lng"=>4.29962,"data"=>array("drive"=>true,"zip"=>30540,"city"=>"MILHAUD")),
  array("lat"=>42.69907,"lng"=>3.02246,"data"=>array("drive"=>true,"zip"=>66140,"city"=>"CANET-EN-ROUSSILLON")),
  array("lat"=>42.69355,"lng"=>2.84787,"data"=>array("drive"=>true,"zip"=>66000,"city"=>"PERPIGNAN")),
  array("lat"=>43.8157,"lng"=>4.34779,"data"=>array("drive"=>true,"zip"=>30900,"city"=>"NÎMES")),
  array("lat"=>43.82215,"lng"=>4.36383,"data"=>array("drive"=>true,"zip"=>30900,"city"=>"NÎMES")),
  array("lat"=>43.84039,"lng"=>4.35795,"data"=>array("drive"=>false,"zip"=>30900,"city"=>"NÎMES")),
  array("lat"=>44.6457,"lng"=>-1.15791,"data"=>array("drive"=>true,"zip"=>33260,"city"=>"LA TESTE-DE-BUCH")),
  array("lat"=>42.68683,"lng"=>2.9069,"data"=>array("drive"=>true,"zip"=>66100,"city"=>"PERPIGNAN")),
  array("lat"=>43.62578,"lng"=>3.8388,"data"=>array("drive"=>true,"zip"=>34080,"city"=>"MONTPELLIER")),
  array("lat"=>42.77677,"lng"=>2.91531,"data"=>array("drive"=>true,"zip"=>66530,"city"=>"CLAIRA")),
  array("lat"=>43.20709,"lng"=>2.31086,"data"=>array("drive"=>true,"zip"=>11000,"city"=>"CARCASSONNE")),
  array("lat"=>43.20738,"lng"=>2.38474,"data"=>array("drive"=>true,"zip"=>11000,"city"=>"CARCASSONNE")),
  array("lat"=>43.60528,"lng"=>3.88051,"data"=>array("drive"=>false,"zip"=>34000,"city"=>"MONTPELLIER")),
  array("lat"=>43.21638,"lng"=>2.35223,"data"=>array("drive"=>false,"zip"=>11000,"city"=>"CARCASSONNE")),
  array("lat"=>45.8406,"lng"=>3.50801,"data"=>array("drive"=>true,"zip"=>63300,"city"=>"THIERS")),
  array("lat"=>46.85164,"lng"=>1.70296,"data"=>array("drive"=>true,"zip"=>36130,"city"=>"DÉOLS")),
  array("lat"=>45.75052,"lng"=>3.13313,"data"=>array("drive"=>true,"zip"=>63170,"city"=>"AUBIÈRE")),
  array("lat"=>46.12527,"lng"=>3.40138,"data"=>array("drive"=>true,"zip"=>3700,"city"=>"BELLERIVE-SUR-ALLIER")),
  array("lat"=>46.80857,"lng"=>4.42863,"data"=>array("drive"=>true,"zip"=>71200,"city"=>"LE CREUSOT")),
  array("lat"=>46.95621,"lng"=>4.31589,"data"=>array("drive"=>true,"zip"=>71400,"city"=>"AUTUN")),
  array("lat"=>47.34747,"lng"=>0.65567,"data"=>array("drive"=>false,"zip"=>37300,"city"=>"JOUÉ-LÈS-TOURS")),
  array("lat"=>47.38969,"lng"=>2.92328,"data"=>array("drive"=>false,"zip"=>58200,"city"=>"COSNE-SUR-LOIRE")),
  array("lat"=>48.19094,"lng"=>6.41851,"data"=>array("drive"=>true,"zip"=>88190,"city"=>"GOLBEY")),
  array("lat"=>49.22098,"lng"=>4.02081,"data"=>array("drive"=>true,"zip"=>51100,"city"=>"REIMS")),
  array("lat"=>48.29201,"lng"=>6.93812,"data"=>array("drive"=>true,"zip"=>88100,"city"=>"SAINT-DIÉ-DES-VOSGES")),
  array("lat"=>48.32859,"lng"=>4.10227,"data"=>array("drive"=>false,"zip"=>10150,"city"=>"PONT-SAINTE-MARIE")),
  array("lat"=>48.29987,"lng"=>4.07339,"data"=>array("drive"=>false,"zip"=>10000,"city"=>"TROYES")),
  array("lat"=>47.64207,"lng"=>6.91232,"data"=>array("drive"=>false,"zip"=>90160,"city"=>"BESSONCOURT")),
  array("lat"=>50.49519,"lng"=>2.57567,"data"=>array("drive"=>true,"zip"=>62700,"city"=>"BRUAY-LA-BUISSIÈRE")),
  array("lat"=>47.84352,"lng"=>5.33092,"data"=>array("drive"=>true,"zip"=>52200,"city"=>"LANGRES")),
  array("lat"=>49.05453,"lng"=>3.95601,"data"=>array("drive"=>true,"zip"=>51200,"city"=>"ÉPERNAY")),
  array("lat"=>47.63153,"lng"=>6.13998,"data"=>array("drive"=>true,"zip"=>70000,"city"=>"VESOUL")),
  array("lat"=>43.10343,"lng"=>0.38671,"data"=>array("drive"=>true,"zip"=>65300,"city"=>"LANNEMEZAN")),
  array("lat"=>44.17682,"lng"=>4.61917,"data"=>array("drive"=>true,"zip"=>30200,"city"=>"BAGNOLS-SUR-CÈZE")),
  array("lat"=>48.82061,"lng"=>2.3642,"data"=>array("drive"=>false,"zip"=>75013,"city"=>"PARIS")),
  array("lat"=>48.83315,"lng"=>2.27745,"data"=>array("drive"=>false,"zip"=>75015,"city"=>"PARIS")),
  array("lat"=>45.14384,"lng"=>5.30524,"data"=>array("drive"=>false,"zip"=>38160,"city"=>"CHATTE")),
  array("lat"=>48.56597,"lng"=>2.44506,"data"=>array("drive"=>true,"zip"=>91540,"city"=>"MENNECY")),
  array("lat"=>49.15382,"lng"=>2.25346,"data"=>array("drive"=>true,"zip"=>60230,"city"=>"CHAMBLY")),
  array("lat"=>49.4784,"lng"=>1.74044,"data"=>array("drive"=>false,"zip"=>76220,"city"=>"FERRIÈRES-EN-BRAY")),
  array("lat"=>49.12537,"lng"=>2.24885,"data"=>array("drive"=>true,"zip"=>95290,"city"=>"L'ISLE-ADAM")),
  array("lat"=>48.83774,"lng"=>-1.55171,"data"=>array("drive"=>true,"zip"=>50400,"city"=>"YQUELON")),
  array("lat"=>50.93452,"lng"=>1.80784,"data"=>array("drive"=>false,"zip"=>62231,"city"=>"COQUELLES")),
  array("lat"=>43.60638,"lng"=>1.48269,"data"=>array("drive"=>true,"zip"=>31500,"city"=>"TOULOUSE")),
  array("lat"=>43.41383,"lng"=>5.35497,"data"=>array("drive"=>true,"zip"=>13170,"city"=>"LES PENNES-MIRABEAU")),
  array("lat"=>50.93712,"lng"=>1.86186,"data"=>array("drive"=>true,"zip"=>62100,"city"=>"CALAIS")),
  array("lat"=>48.45399,"lng"=>-2.49809,"data"=>array("drive"=>false,"zip"=>22400,"city"=>"LAMBALLE")),
  array("lat"=>45.02697,"lng"=>3.88085,"data"=>array("drive"=>true,"zip"=>43750,"city"=>"VALS-PRÈS-LE-PUY")),
  array("lat"=>45.89693,"lng"=>0.92074,"data"=>array("drive"=>true,"zip"=>87200,"city"=>"SAINT-JUNIEN")),
  array("lat"=>43.1893,"lng"=>5.60407,"data"=>array("drive"=>true,"zip"=>13600,"city"=>"LA CIOTAT")),
  array("lat"=>48.60279,"lng"=>7.75749,"data"=>array("drive"=>true,"zip"=>67300,"city"=>"SCHILTIGHEIM")),
  array("lat"=>49.89176,"lng"=>2.30147,"data"=>array("drive"=>false,"zip"=>80000,"city"=>"AMIENS")),
  array("lat"=>48.14025,"lng"=>-1.76788,"data"=>array("drive"=>true,"zip"=>35740,"city"=>"PACÉ")),
  array("lat"=>50.3411,"lng"=>3.51568,"data"=>array("drive"=>true,"zip"=>59300,"city"=>"VALENCIENNES")),
  array("lat"=>45.05044,"lng"=>5.07591,"data"=>array("drive"=>true,"zip"=>26100,"city"=>"ROMANS-SUR-ISÈRE")),
  array("lat"=>43.30388,"lng"=>5.41783,"data"=>array("drive"=>false,"zip"=>13012,"city"=>"MARSEILLE")),
  array("lat"=>47.76301,"lng"=>-3.39515,"data"=>array("drive"=>true,"zip"=>56100,"city"=>"LORIENT")),
  array("lat"=>43.18081,"lng"=>5.69577,"data"=>array("drive"=>true,"zip"=>83270,"city"=>"SAINT-CYR-SUR-MER")),
  array("lat"=>43.20332,"lng"=>6.05078,"data"=>array("drive"=>true,"zip"=>83210,"city"=>"SOLLIÈS-PONT")),
  array("lat"=>44.54519,"lng"=>6.0636,"data"=>array("drive"=>true,"zip"=>5000,"city"=>"GAP")),
  array("lat"=>49.61259,"lng"=>0.77528,"data"=>array("drive"=>true,"zip"=>76190,"city"=>"YVETOT")),
  array("lat"=>50.35834,"lng"=>3.52377,"data"=>array("drive"=>false,"zip"=>59300,"city"=>"VALENCIENNES")),
  array("lat"=>49.75904,"lng"=>0.37586,"data"=>array("drive"=>false,"zip"=>76400,"city"=>"FÉCAMP")),
  array("lat"=>49.37964,"lng"=>6.1705,"data"=>array("drive"=>true,"zip"=>57100,"city"=>"MANOM")),
  array("lat"=>43.39371,"lng"=>5.13163,"data"=>array("drive"=>true,"zip"=>13220,"city"=>"CHÂTEAUNEUF-LES-MARTIGUES")),
  array("lat"=>48.63598,"lng"=>2.31977,"data"=>array("drive"=>false,"zip"=>91240,"city"=>"SAINT-MICHEL-SUR-ORGE")),
  array("lat"=>43.41284,"lng"=>5.00081,"data"=>array("drive"=>true,"zip"=>13110,"city"=>"PORT-DE-BOUC")),
  array("lat"=>43.70487,"lng"=>7.26519,"data"=>array("drive"=>false,"zip"=>6000,"city"=>"NICE")),
  array("lat"=>43.60686,"lng"=>1.30559,"data"=>array("drive"=>true,"zip"=>31770,"city"=>"COLOMIERS")),
  array("lat"=>48.83655,"lng"=>2.66448,"data"=>array("drive"=>false,"zip"=>77090,"city"=>"COLLÉGIEN")),
  array("lat"=>47.25079,"lng"=>-1.61928,"data"=>array("drive"=>true,"zip"=>44800,"city"=>"SAINT-HERBLAIN")),
  array("lat"=>48.86924,"lng"=>2.78517,"data"=>array("drive"=>false,"zip"=>77700,"city"=>"CHESSY")),
  array("lat"=>49.19121,"lng"=>6.14659,"data"=>array("drive"=>true,"zip"=>57280,"city"=>"SEMÉCOURT")),
  array("lat"=>42.5346,"lng"=>2.84056,"data"=>array("drive"=>true,"zip"=>66160,"city"=>"LE BOULOU")),
  array("lat"=>43.26346,"lng"=>6.57826,"data"=>array("drive"=>true,"zip"=>83580,"city"=>"GASSIN")),
  array("lat"=>50.3467,"lng"=>3.28313,"data"=>array("drive"=>true,"zip"=>59490,"city"=>"SOMAIN")),
  array("lat"=>48.61677,"lng"=>2.54938,"data"=>array("drive"=>false,"zip"=>77127,"city"=>"LIEUSAINT")),
  array("lat"=>43.51744,"lng"=>4.15006,"data"=>array("drive"=>true,"zip"=>30240,"city"=>"LE GRAU-DU-ROI")),
  array("lat"=>43.43126,"lng"=>6.80437,"data"=>array("drive"=>true,"zip"=>83700,"city"=>"SAINT-RAPHAËL")),
  array("lat"=>44.92761,"lng"=>-0.23948,"data"=>array("drive"=>false,"zip"=>33500,"city"=>"LIBOURNE")),
  array("lat"=>50.7383,"lng"=>2.54634,"data"=>array("drive"=>true,"zip"=>59190,"city"=>"HAZEBROUCK")),
  array("lat"=>50.25749,"lng"=>3.93521,"data"=>array("drive"=>false,"zip"=>59720,"city"=>"LOUVROIL")),
  array("lat"=>48.8302,"lng"=>2.35596,"data"=>array("drive"=>false,"zip"=>75013,"city"=>"PARIS")),
  array("lat"=>47.89024,"lng"=>-3.91489,"data"=>array("drive"=>true,"zip"=>29900,"city"=>"CONCARNEAU")),
  array("lat"=>46.37976,"lng"=>5.83763,"data"=>array("drive"=>true,"zip"=>39200,"city"=>"SAINT-CLAUDE")),
  array("lat"=>50.73301,"lng"=>1.67089,"data"=>array("drive"=>true,"zip"=>62280,"city"=>"SAINT-MARTIN-BOULOGNE")),
  array("lat"=>48.01678,"lng"=>6.61486,"data"=>array("drive"=>true,"zip"=>88200,"city"=>"SAINT-ÉTIENNE-LÈS-REMIREMONT")),
  array("lat"=>45.92441,"lng"=>6.12388,"data"=>array("drive"=>false,"zip"=>74000,"city"=>"ANNECY")),
  array("lat"=>44.36068,"lng"=>2.57027,"data"=>array("drive"=>true,"zip"=>12000,"city"=>"RODEZ")),
  array("lat"=>42.5588,"lng"=>3.00721,"data"=>array("drive"=>true,"zip"=>66700,"city"=>"ARGELÈS-SUR-MER")),
  array("lat"=>47.9756,"lng"=>0.15911,"data"=>array("drive"=>true,"zip"=>72700,"city"=>"ALLONNES")),
  array("lat"=>44.83033,"lng"=>-0.65312,"data"=>array("drive"=>true,"zip"=>33700,"city"=>"MÉRIGNAC")),
  array("lat"=>47.92024,"lng"=>-2.38758,"data"=>array("drive"=>true,"zip"=>56800,"city"=>"PLOËRMEL")),
  array("lat"=>45.31051,"lng"=>-0.93967,"data"=>array("drive"=>true,"zip"=>33340,"city"=>"LESPARRE-MÉDOC")),
  array("lat"=>43.30251,"lng"=>5.38128,"data"=>array("drive"=>false,"zip"=>13001,"city"=>"MARSEILLE")),
  array("lat"=>48.05528,"lng"=>-1.73987,"data"=>array("drive"=>true,"zip"=>35170,"city"=>"BRUZ")),
  array("lat"=>48.60384,"lng"=>-1.97581,"data"=>array("drive"=>true,"zip"=>35430,"city"=>"SAINT-JOUAN-DES-GUÉRETS")),
  array("lat"=>43.63363,"lng"=>7.13402,"data"=>array("drive"=>true,"zip"=>6270,"city"=>"VILLENEUVE-LOUBET")),
  array("lat"=>45.20267,"lng"=>5.76699,"data"=>array("drive"=>false,"zip"=>38240,"city"=>"MEYLAN")),
  array("lat"=>48.18011,"lng"=>-2.73124,"data"=>array("drive"=>false,"zip"=>22600,"city"=>"LOUDÉAC")),
  array("lat"=>48.74828,"lng"=>1.92426,"data"=>array("drive"=>true,"zip"=>78310,"city"=>"COIGNIÈRES")),
  array("lat"=>48.96362,"lng"=>2.29001,"data"=>array("drive"=>true,"zip"=>95210,"city"=>"SAINT-GRATIEN")),
  array("lat"=>43.00557,"lng"=>1.12611,"data"=>array("drive"=>true,"zip"=>9190,"city"=>"SAINT-LIZIER")),
  array("lat"=>48.87308,"lng"=>2.33243,"data"=>array("drive"=>false,"zip"=>75009,"city"=>"PARIS")),
  array("lat"=>48.86753,"lng"=>2.36292,"data"=>array("drive"=>false,"zip"=>75003,"city"=>"PARIS")),
  array("lat"=>43.32439,"lng"=>-0.3796,"data"=>array("drive"=>true,"zip"=>64140,"city"=>"LONS")),
  array("lat"=>48.87176,"lng"=>2.33906,"data"=>array("drive"=>false,"zip"=>75002,"city"=>"PARIS")),
  array("lat"=>47.97502,"lng"=>0.21526,"data"=>array("drive"=>true,"zip"=>72100,"city"=>"LE MANS")),
  array("lat"=>43.49787,"lng"=>4.98064,"data"=>array("drive"=>true,"zip"=>13800,"city"=>"ISTRES")),
  array("lat"=>43.5197,"lng"=>4.9642,"data"=>array("drive"=>true,"zip"=>13800,"city"=>"ISTRES")),
  array("lat"=>43.93186,"lng"=>5.06423,"data"=>array("drive"=>true,"zip"=>84800,"city"=>"L'ISLE-SUR-LA-SORGUE")),
  array("lat"=>49.86278,"lng"=>2.27729,"data"=>array("drive"=>true,"zip"=>80480,"city"=>"DURY")),
  array("lat"=>43.60812,"lng"=>3.88582,"data"=>array("drive"=>false,"zip"=>34000,"city"=>"MONTPELLIER")),
  array("lat"=>48.80373,"lng"=>3.0886,"data"=>array("drive"=>true,"zip"=>77120,"city"=>"COULOMMIERS")),
  array("lat"=>45.97949,"lng"=>4.73477,"data"=>array("drive"=>true,"zip"=>69400,"city"=>"VILLEFRANCHE-SUR-SAÔNE")),
  array("lat"=>48.55121,"lng"=>3.2956,"data"=>array("drive"=>true,"zip"=>77160,"city"=>"PROVINS")),
  array("lat"=>48.3759,"lng"=>2.95623,"data"=>array("drive"=>true,"zip"=>77130,"city"=>"MONTEREAU-FAULT-YONNE")),
  array("lat"=>49.73305,"lng"=>4.75233,"data"=>array("drive"=>true,"zip"=>8000,"city"=>"VILLERS-SEMEUSE")),
  array("lat"=>44.50943,"lng"=>0.14167,"data"=>array("drive"=>true,"zip"=>47200,"city"=>"MARMANDE")),
  array("lat"=>49.27604,"lng"=>-0.10364,"data"=>array("drive"=>true,"zip"=>14160,"city"=>"DIVES-SUR-MER")),
  array("lat"=>48.84724,"lng"=>2.43692,"data"=>array("drive"=>false,"zip"=>94300,"city"=>"VINCENNES")),
  array("lat"=>48.02243,"lng"=>0.22789,"data"=>array("drive"=>true,"zip"=>72000,"city"=>"LE MANS")),
  array("lat"=>48.86328,"lng"=>1.45958,"data"=>array("drive"=>false,"zip"=>28260,"city"=>"ANET")),
  array("lat"=>49.5494,"lng"=>3.61421,"data"=>array("drive"=>true,"zip"=>2000,"city"=>"LAON")),
  array("lat"=>43.52929,"lng"=>6.47141,"data"=>array("drive"=>true,"zip"=>83300,"city"=>"DRAGUIGNAN")),
  array("lat"=>43.70025,"lng"=>7.27869,"data"=>array("drive"=>false,"zip"=>6300,"city"=>"NICE")),
  array("lat"=>48.81032,"lng"=>2.3285,"data"=>array("drive"=>false,"zip"=>94110,"city"=>"ARCUEIL")),
  array("lat"=>48.72844,"lng"=>2.43442,"data"=>array("drive"=>true,"zip"=>94290,"city"=>"VILLENEUVE-LE-ROI")),
  array("lat"=>50.68157,"lng"=>3.12795,"data"=>array("drive"=>true,"zip"=>59290,"city"=>"WASQUEHAL")),
  array("lat"=>44.54815,"lng"=>6.4821,"data"=>array("drive"=>true,"zip"=>5200,"city"=>"BARATIER")),
  array("lat"=>43.10359,"lng"=>1.63003,"data"=>array("drive"=>true,"zip"=>9100,"city"=>"PAMIERS")),
  array("lat"=>43.07452,"lng"=>2.21976,"data"=>array("drive"=>true,"zip"=>11300,"city"=>"LIMOUX")),
  array("lat"=>50.47552,"lng"=>3.2351,"data"=>array("drive"=>false,"zip"=>59310,"city"=>"ORCHIES")),
  array("lat"=>48.11598,"lng"=>-1.709,"data"=>array("drive"=>false,"zip"=>35000,"city"=>"RENNES")),
  array("lat"=>47.0944,"lng"=>-1.00618,"data"=>array("drive"=>true,"zip"=>49450,"city"=>"SAINT-ANDRÉ-DE-LA-MARCHE")),
  array("lat"=>49.56975,"lng"=>2.9801,"data"=>array("drive"=>true,"zip"=>60400,"city"=>"NOYON")),
  array("lat"=>49.40969,"lng"=>2.78425,"data"=>array("drive"=>false,"zip"=>60280,"city"=>"VENETTE")),
  array("lat"=>43.81766,"lng"=>4.61405,"data"=>array("drive"=>true,"zip"=>30300,"city"=>"BEAUCAIRE")),
  array("lat"=>43.45525,"lng"=>5.84918,"data"=>array("drive"=>false,"zip"=>83470,"city"=>"SAINT-MAXIMIN-LA-SAINTE-BAUME")),
  array("lat"=>43.40905,"lng"=>6.04965,"data"=>array("drive"=>true,"zip"=>83170,"city"=>"BRIGNOLES")),
  array("lat"=>43.55214,"lng"=>7.01534,"data"=>array("drive"=>false,"zip"=>6400,"city"=>"CANNES")),
  array("lat"=>43.46599,"lng"=>5.60611,"data"=>array("drive"=>true,"zip"=>13710,"city"=>"FUVEAU")),
  array("lat"=>46.98855,"lng"=>3.16448,"data"=>array("drive"=>true,"zip"=>58000,"city"=>"NEVERS")),
  array("lat"=>48.39687,"lng"=>2.95274,"data"=>array("drive"=>false,"zip"=>77130,"city"=>"MONTEREAU-FAULT-YONNE")),
  array("lat"=>44.05703,"lng"=>1.10027,"data"=>array("drive"=>true,"zip"=>82100,"city"=>"CASTELSARRASIN")),
  array("lat"=>49.86364,"lng"=>3.29186,"data"=>array("drive"=>true,"zip"=>2100,"city"=>"SAINT-QUENTIN")),
  array("lat"=>48.80961,"lng"=>2.47142,"data"=>array("drive"=>false,"zip"=>94100,"city"=>"SAINT-MAUR-DES-FOSSÉS")),
  array("lat"=>49.1565,"lng"=>1.34836,"data"=>array("drive"=>true,"zip"=>27600,"city"=>"GAILLON")),
  array("lat"=>45.75395,"lng"=>4.80552,"data"=>array("drive"=>true,"zip"=>69005,"city"=>"LYON")),
  array("lat"=>50.58694,"lng"=>3.08732,"data"=>array("drive"=>true,"zip"=>59810,"city"=>"LESQUIN")),
  array("lat"=>48.76961,"lng"=>2.06097,"data"=>array("drive"=>true,"zip"=>78280,"city"=>"GUYANCOURT")),
  array("lat"=>48.59721,"lng"=>1.67741,"data"=>array("drive"=>false,"zip"=>28130,"city"=>"HANCHES")),
  array("lat"=>48.70738,"lng"=>2.49575,"data"=>array("drive"=>true,"zip"=>91330,"city"=>"YERRES")),
  array("lat"=>46.12793,"lng"=>5.81155,"data"=>array("drive"=>true,"zip"=>1200,"city"=>"CHÂTILLON-EN-MICHAILLE")),
  array("lat"=>48.80561,"lng"=>2.13137,"data"=>array("drive"=>true,"zip"=>78000,"city"=>"VERSAILLES")),
  array("lat"=>48.84728,"lng"=>2.3866,"data"=>array("drive"=>false,"zip"=>75012,"city"=>"PARIS")),
  array("lat"=>48.4987,"lng"=>2.35171,"data"=>array("drive"=>true,"zip"=>91760,"city"=>"ITTEVILLE")),
  array("lat"=>49.2861,"lng"=>-0.70443,"data"=>array("drive"=>true,"zip"=>14400,"city"=>"BAYEUX")),
  array("lat"=>48.58519,"lng"=>2.44699,"data"=>array("drive"=>false,"zip"=>91100,"city"=>"VILLABÉ")),
  array("lat"=>48.87389,"lng"=>2.38512,"data"=>array("drive"=>false,"zip"=>75019,"city"=>"PARIS")),
  array("lat"=>43.96112,"lng"=>4.74895,"data"=>array("drive"=>true,"zip"=>30133,"city"=>"LES ANGLES")),
  array("lat"=>44.90226,"lng"=>1.21115,"data"=>array("drive"=>true,"zip"=>24200,"city"=>"SARLAT-LA-CANÉDA")),
  array("lat"=>44.95616,"lng"=>-0.62945,"data"=>array("drive"=>false,"zip"=>33290,"city"=>"LE PIAN-MÉDOC")),
  array("lat"=>48.73409,"lng"=>1.36299,"data"=>array("drive"=>true,"zip"=>28100,"city"=>"DREUX")),
  array("lat"=>48.68341,"lng"=>2.53421,"data"=>array("drive"=>true,"zip"=>91800,"city"=>"BOUSSY-SAINT-ANTOINE")),
  array("lat"=>49.3904,"lng"=>2.78926,"data"=>array("drive"=>true,"zip"=>60200,"city"=>"COMPIÈGNE")),
  array("lat"=>45.46378,"lng"=>4.39978,"data"=>array("drive"=>true,"zip"=>42000,"city"=>"SAINT-ÉTIENNE")),
  array("lat"=>48.89107,"lng"=>2.23926,"data"=>array("drive"=>false,"zip"=>92800,"city"=>"PUTEAUX")),
  array("lat"=>48.57722,"lng"=>7.76786,"data"=>array("drive"=>false,"zip"=>67000,"city"=>"STRASBOURG")),
  array("lat"=>47.28372,"lng"=>-1.45321,"data"=>array("drive"=>false,"zip"=>44470,"city"=>"CARQUEFOU")),
  array("lat"=>48.57474,"lng"=>7.7561,"data"=>array("drive"=>false,"zip"=>67100,"city"=>"STRASBOURG")),
  array("lat"=>48.69417,"lng"=>6.12801,"data"=>array("drive"=>true,"zip"=>54520,"city"=>"LAXOU")),
  array("lat"=>47.33718,"lng"=>5.03413,"data"=>array("drive"=>true,"zip"=>21121,"city"=>"FONTAINE-LÈS-DIJON")),
  array("lat"=>43.3069,"lng"=>-0.33246,"data"=>array("drive"=>true,"zip"=>64000,"city"=>"PAU")),
  array("lat"=>48.08946,"lng"=>1.33393,"data"=>array("drive"=>true,"zip"=>28200,"city"=>"CHÂTEAUDUN")),
  array("lat"=>45.77578,"lng"=>4.80164,"data"=>array("drive"=>false,"zip"=>69009,"city"=>"LYON")),
  array("lat"=>48.95702,"lng"=>2.88461,"data"=>array("drive"=>false,"zip"=>77100,"city"=>"MEAUX")),
  array("lat"=>48.90731,"lng"=>2.48977,"data"=>array("drive"=>false,"zip"=>93140,"city"=>"BONDY")),
  array("lat"=>48.83039,"lng"=>2.70975,"data"=>array("drive"=>true,"zip"=>77600,"city"=>"BUSSY-SAINT-GEORGES")),
  array("lat"=>49.03751,"lng"=>1.59336,"data"=>array("drive"=>true,"zip"=>78840,"city"=>"FRENEUSE")),
  array("lat"=>49.20864,"lng"=>2.60246,"data"=>array("drive"=>true,"zip"=>60300,"city"=>"SENLIS")),
  array("lat"=>50.33293,"lng"=>3.51211,"data"=>array("drive"=>true,"zip"=>59300,"city"=>"AULNOY-LEZ-VALENCIENNES")),
  array("lat"=>50.40613,"lng"=>2.9762,"data"=>array("drive"=>true,"zip"=>62110,"city"=>"HÉNIN-BEAUMONT")),
  array("lat"=>48.95827,"lng"=>2.32945,"data"=>array("drive"=>true,"zip"=>93800,"city"=>"ÉPINAY-SUR-SEINE")),
  array("lat"=>47.38091,"lng"=>-1.64448,"data"=>array("drive"=>false,"zip"=>44810,"city"=>"HÉRIC")),
  array("lat"=>46.97047,"lng"=>-1.33153,"data"=>array("drive"=>false,"zip"=>85600,"city"=>"BOUFFÉRÉ")),
  array("lat"=>46.04532,"lng"=>4.05548,"data"=>array("drive"=>true,"zip"=>42153,"city"=>"RIORGES")),
  array("lat"=>45.35301,"lng"=>5.33501,"data"=>array("drive"=>true,"zip"=>38590,"city"=>"SAINT-ÉTIENNE-DE-SAINT-GEOIRS")),
  array("lat"=>45.86416,"lng"=>6.62534,"data"=>array("drive"=>false,"zip"=>74120,"city"=>"MEGÈVE")),
  array("lat"=>47.48832,"lng"=>-0.54378,"data"=>array("drive"=>true,"zip"=>49100,"city"=>"ANGERS")),
  array("lat"=>43.17459,"lng"=>2.99269,"data"=>array("drive"=>true,"zip"=>11100,"city"=>"NARBONNE"))
);

$json = array(
  "center" => array(46.578498,2.457275),
  "macDoList" => $macDoList
);

header('Content-Type: text/json; charset=UTF-8;');
echo json_encode( $json );

?>